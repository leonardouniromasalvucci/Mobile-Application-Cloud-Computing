const cool = require('cool-ascii-faces')
const express = require('express')
const path = require('path')
const { Pool } = require('pg');
var DATABASE_URL = "postgres://ammcbhghixoaie:a3e93442550d49c902474028ae2f073ca04c21d7926f4af26d3f7afbd9264ee4@ec2-174-129-25-182.compute-1.amazonaws.com:5432/dce65uahc3ngrr";
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: true
});
const PORT = process.env.PORT || 5000


express()
  .use(express.static(path.join(__dirname, 'public')))
  .set('views', path.join(__dirname, 'views'))
  .set('view engine', 'ejs')
  .get('/', (req, res) => res.render('pages/index'))
  .get('/cool', (req, res) => res.send(cool()))
  .get('/get_db', async (req, res) => {
    try {
      const client = await pool.connect()
      const result = await client.query('SELECT * FROM tab_users');
      const results = { 'results': (result) ? result.rows : null};
      res.render('pages/db', results );
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  })
  .get('/login', async (req, res) => {
    try {
      const client = await pool.connect()
      var username = req.query.username;
      var password = req.query.password;
      var result = await client.query('SELECT id FROM tab_users WHERE name=$1 AND password=$2',[username,  password]);
      var r = result.rows[0];
      var rr = JSON.stringify(r);
      try{
      	var rrr = rr.substring(rr.indexOf(":")+1,rr.indexOf("}"));
      	res.send(rrr);
      }catch(err){
      	res.send("");
      }
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  })
  .get('/create_db', async (req, res) => {
    try {
      const client = await pool.connect()
      const result = await client.query( "CREATE TABLE tab_users(id SERIAL PRIMARY KEY, id_face VARCHAR(40), name VARCHAR(40) NOT NULL, email VARCHAR(40) NOT NULL, password  VARCHAR(40) NOT NULL, dates VARCHAR(40) NOT NULL)");
      const results = { 'results': (result) ? result.rows : null};
      res.render('pages/db', results );
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  })
  .get('/test_db', async (req, res) => {
    try {
      const client = await pool.connect()
      var username = req.query.username;
      var email = req.query.email;
      var password = req.query.password;
      var date = req.query.date;
      const result = await client.query('INSERT INTO tab_users(id_face,name,email,password,dates) values($1,$2,$3,$4,$5)',[null,username, email, password, date]);
      res.render('pages/test_db', "Fine!");
      res.send("fine");
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  })
  .get('/clear_db', async (req, res) => {
    try {
      const client = await pool.connect()
      const result = await client.query('DELETE FROM tab_users');
      res.send("OK");
      client.release();
    } catch (err) {
      console.error(err);
      res.send("Error " + err);
    }
  })
  .get('/test',function(req,res){
	  res.render('pages/test');
  })
  .listen(PORT, () => console.log(`Listening on ${ PORT }`))
