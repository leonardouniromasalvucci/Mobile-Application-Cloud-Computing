package com.example.leonardo.questionpage;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class GeneralQuestion extends AppCompatActivity {


    TextView question, category, response;
    Context cc;

    //Button buttos;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_question);

         // for set actionbar title
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Answer");

        question = (TextView)findViewById(R.id.question);
        category = (TextView)findViewById(R.id.category);
        response = (TextView)findViewById(R.id.answer);
       // buttos = (Button)findViewById(R.id.button_q);
        cc=this;

        Bundle b = getIntent().getExtras();
        int value = -1; // or other values
        if(b != null) {
            value = b.getInt("key");
            Log.v("m",""+value);
            ArrayList<Answer> list_ans = getDatas();
            for(int i=0; i<list_ans.size(); i++){
                if(list_ans.get(i).getCod()==value){

                    question.setText(list_ans.get(i).getQuestion());
                    category.setText(list_ans.get(i).getCategory());
                    response.setText(list_ans.get(i).getResponse());
                }
            }

        }







       /* Answer a1 = new Answer(0,"General", "Where is my place", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a2 = new Answer(1,"Friends", "Where is my place", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a3 = new Answer(2,"Location", "Where is my place", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a4 = new Answer(3,"Notifications", "Where is my place", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a5 = new Answer(4,"General", "Where is my place", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        list_ans.add(a1);
        list_ans.add(a2);
        list_ans.add(a3);
        list_ans.add(a4);
        list_ans.add(a5);*/





    }

    public ArrayList<Answer> getDatas(){
        ArrayList<Answer> list_ans = new ArrayList<>();
        List<User> l = AppDatabase.getAppDatabase(cc).userDao().getAllFAQ();
        for(int i=0; i<l.size(); i++){
            if(l.get(i).getAge()==1){
                list_ans.add(new Answer(2,"General",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==2){
                list_ans.add(new Answer(3,"Location",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==3){
                list_ans.add(new Answer(1,"Friends",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==4){
                list_ans.add(new Answer(4,"Notifications",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==5){
                list_ans.add(new Answer(0,"Contact",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==6){
                list_ans.add(new Answer(5,"Setting",l.get(i).getFirstName(),l.get(i).getLastName()));
            }

        }
        return list_ans;
    }
    public void onClickBtn(View v){
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


}
