package com.example.leonardo.questionpage;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class Answer {
    public int cod;
    public String category;
    public String question;


    public Answer(int cod, String category, String question, String response) {
        this.cod = cod;
        this.category = category;
        this.question = question;
        this.response = response;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String response;

    public static ArrayList<Answer> getQuestionAnswer(){


        ArrayList<Answer> list_ans = new ArrayList<Answer>();

     /*   List<User> l = AppDatabase.getAppDatabase(cc).userDao().getAllFAQ();
        for(int i=0; i<l.size(); i++){
            list_ans.add(new Answer(i, "General",l.get(i).getFirstName(),l.get(i).getLastName()));
        }*/
       /* Answer a1 = new Answer(0,"General", "Where is my place", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a2 = new Answer(1,"Friends", "Can I block friends?", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a3 = new Answer(2,"Location", "Connection is not avaible", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a4 = new Answer(3,"Notifications", "Can I effect the report", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a5 = new Answer(4,"General", "When I use the app", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a6 = new Answer(5,"Friends", "Can get m telephone?", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a7 = new Answer(6,"Notifications", "Where is my friend", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a8 = new Answer(7,"General", "Can I effect the report", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a9 = new Answer(8,"General", "When I use the app", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a10 = new Answer(9,"Setting", "Can i setting the app?", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a11 = new Answer(10,"Contact", "Contact us is free?", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
        Answer a12 = new Answer(11,"Contact", "Is so easy getr my name?", "Yes, you'd have to make the session ID available to every activity where you want to allow the user to signout. Alternatively, you could store it in the Application object, but then you'd have to manage the state of the session (check if it's valid before using, etc)");
*/
        /*list_ans.add(a1);
        list_ans.add(a2);
        list_ans.add(a3);
        list_ans.add(a4);
        list_ans.add(a5);
        list_ans.add(a6);
        list_ans.add(a7);
        list_ans.add(a8);
        list_ans.add(a9);
        list_ans.add(a10);
        list_ans.add(a11);
        list_ans.add(a12);*/

        return list_ans;
    }
}
