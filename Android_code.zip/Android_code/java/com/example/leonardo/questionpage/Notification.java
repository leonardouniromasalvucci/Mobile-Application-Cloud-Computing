package com.example.leonardo.questionpage;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewTreeObserver;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.appyvet.materialrangebar.RangeBar;
import com.facebook.login.LoginManager;

public class Notification extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

   RangeBar slider;
   TextView range;
   TextView txt1, custom;
   LinearLayout l,l1,l2, sound, l3;
   Switch sw1, sw2, sw3;
   float num = 9;
    SeekBar seekBar;
    TextView  meters;


    LayoutInflater inflater;
    View rowView;
    TextView t;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        seekBar = (SeekBar)findViewById(R.id.seek);
        meters = (TextView)findViewById(R.id.text1122);




        //slider = (RangeBar)findViewById(R.id.sekks);
      //  range = (TextView)findViewById(R.id.range);
        //txt1 = (TextView) findViewById(R.id.text1);
     //   txt2 = (TextView) findViewById(R.id.text2);
        l = (LinearLayout)findViewById(R.id.linea1);

        l.setVisibility(View.INVISIBLE);
        l1 = (LinearLayout)findViewById(R.id.linea2);
       // l1.setVisibility(View.INVISIBLE);
      //  l2 = (LinearLayout)findViewById(R.id.linea3);
        sw1 = (Switch)findViewById(R.id.switch1);
        sw2 = (Switch)findViewById(R.id.switch3);
        sw3 = (Switch)findViewById(R.id.switch2);
       // sw3 = (Switch)findViewById(R.id.switch4);
        getSupportActionBar().setTitle("Notifications");
        loadSavedPreferences();
        loadSavedPreferences1();


        custom = (TextView)findViewById(R.id.chooseBlack);

        inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        rowView = inflater.inflate(R.layout.sounds, null);


        t = (TextView)rowView.findViewById(R.id.text2);


        sw1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                savePreferences("allow", sw1.isChecked());
                if(isChecked){
                   /* for ( int i = 0; i < l.getChildCount();  i++ ){
                        View view = l.getChildAt(i);
                        view.setEnabled(true);
                        view.setAlpha(1f);// Or whatever you want to do with the view.
                    }*/
                    l.setVisibility(View.VISIBLE);
                }
                else {
                  /*  for ( int i = 0; i < l.getChildCount();  i++ ){
                        View view = l.getChildAt(i);
                        view.setEnabled(false);
                        view.setAlpha(0.2f);// Or whatever you want to do with the view.
                    }*/
                    l.setVisibility(View.INVISIBLE);
                }
            }
        });
        sw2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                savePreferences("sound", sw2.isChecked());
                if(isChecked){
                   /* LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                    l1.addView(rowView, l1.getChildCount());


                    t.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            openSoundChoose();
                        }
                    });*/

                  //  l1.setVisibility(View.VISIBLE);
                }else {
                    l1.removeAllViews();

                 //   l1.setVisibility(View.INVISIBLE);
                }
            }
        });
        sw3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                savePreferences("vibration", sw3.isChecked());
                if(isChecked){
                   /* for ( int i = 0; i < l2.getChildCount();  i++ ){
                        View view = l2.getChildAt(i);
                        //view.setEnabled(true);
                        //view.setAlpha(1f);// Or whatever you want to do with the view.
                        view.setVisibility(View.VISIBLE);
                    }*/
                }
                else {
                    /*for ( int i = 0; i < l2.getChildCount();  i++ ){
                        View view = l2.getChildAt(i);
                        //view.setEnabled(false);
                        //view.setAlpha(0.2f);// Or whatever you want to do with the view.
                        view.setVisibility(View.INVISIBLE);
                    }*/
                }
            }
        });
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // TODO Auto-generated method stub
                meters.setText(String.valueOf(progress)+"m");
                savePreferences1("distances", progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
        });




        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);



       /* txt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSoundChoose();
            }
        });*/
       /* txt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSoundChoose();
            }
        });*/


       /* slider.setOnRangeBarChangeListener(new RangeBar.OnRangeBarChangeListener() {
            @Override
            public void onRangeChangeListener(RangeBar rangeBar, int leftPinIndex, int rightPinIndex, String leftPinValue, String rightPinValue) {
                range.setText("Define range in meters ("+leftPinValue+" - "+rightPinValue+")");
            }

        });*/

        custom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent = new Intent(getApplicationContext(), CustomizeNotification.class);
                startActivity(Intent);
            }
        });

    }
    private void loadSavedPreferences1() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        int distances = sharedPreferences.getInt("distances", 1000);
        meters.setText(String.valueOf(distances)+"m");
        seekBar.setProgress(distances);
    }

    private void savePreferences1(String key, int value) {
        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.commit();


        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref2", MODE_PRIVATE);
        SharedPreferences.Editor editors = pref.edit();
        editors.putInt(key, value);           // Saving boolean - true/false
        editors.commit(); // commit changes

    }

    private void loadSavedPreferences() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        boolean checkBoxValue1 = sharedPreferences.getBoolean("allow", false);
        if (checkBoxValue1) {
            sw1.setChecked(true);
            l.setVisibility(View.VISIBLE);
        } else {
            sw1.setChecked(false);
            l.setVisibility(View.INVISIBLE);
        }
        boolean checkBoxValue2 = sharedPreferences.getBoolean("sound", false);
        if (checkBoxValue2) {
            sw2.setChecked(true);
        } else {
            sw2.setChecked(false);
        }
        boolean checkBoxValue3 = sharedPreferences.getBoolean("vibration", false);
        if (checkBoxValue3) {
            sw3.setChecked(true);
        } else {
            sw3.setChecked(false);
        }
    }

    public boolean getFirstSwitch(){
        return sw1.isChecked();
    }
    public boolean getSecondSwitch(){
        return sw3.isChecked();
    }
    public boolean getThirdSwitch(){
        return sw2.isChecked();
    }

    private void savePreferences(String key, boolean value) {
        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.commit();

        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
        SharedPreferences.Editor editors = pref.edit();
        editors.putBoolean(key, value);           // Saving boolean - true/false
        editors.commit(); // commit changes
    }



    public void openSoundChoose(){
        Intent intent;
        intent = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION);
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Tone");
        intent.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, (Uri) null);
        this.startActivityForResult(intent, 5);
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent intent)
    {
        if (resultCode == Activity.RESULT_OK && requestCode == 5)
        {


            Uri uri = intent.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            Ringtone ringtone = RingtoneManager.getRingtone(this, uri);
            String title = ringtone.getTitle(this);

            if (uri != null){
                t.setText(title);
            }else{

            }
        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.notification, menu);
        return true;
    }

  /*  @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            // Handle the camera action
            Intent Intent = new Intent(this, HomePage.class);
            startActivity(Intent);
        } else if (id == R.id.notification) {
            Intent Intent = new Intent(this, Notification.class);
            startActivity(Intent);

        }else if (id == R.id.friend) {
            Intent Intent = new Intent(this, Friends.class);
            startActivity(Intent);

        } /*else if (id == R.id.manual) {
            Intent Intent = new Intent(this, Manual.class);
            startActivity(Intent);
        }*/ else if (id == R.id.questions) {
            Intent Intent = new Intent(this, Last.class);
            startActivity(Intent);
        }else if (id == R.id.contact) {
            Intent Intent = new Intent(this, ContactUs.class);
            startActivity(Intent);
        }else if (id == R.id.exit) {
            LoginManager.getInstance().logOut();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            System.exit(1);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
