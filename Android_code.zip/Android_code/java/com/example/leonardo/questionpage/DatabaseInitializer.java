package com.example.leonardo.questionpage;

import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.util.Log;

import java.util.List;

public class DatabaseInitializer {

    private static final String TAG = DatabaseInitializer.class.getName();

    public static void populateAsync(@NonNull final AppDatabase db) {
       // removeall(db);
        PopulateDbAsync task = new PopulateDbAsync(db);
        task.execute();
    }

    public static void populateSync(@NonNull final AppDatabase db) {
        populateWithTestData(db);
    }

    private static User addUser(final AppDatabase db, User user) {
        db.userDao().insertAll(user);
        return user;
    }

    private static void removeall(final AppDatabase db) {
        db.userDao().removes();
    }

    private static void populateWithTestData(AppDatabase db) {

        User user = new User();
        user.setFirstName("Introduction");
        user.setLastName("Achieving complex and difficult goals requires focus, long-term diligence and effort (see Goal pursuit). Success in any field requires forgoing excuses and justifications for poor performance or lack of adequate planning; in short, success requires emotional maturity. The measure of belief that people have in their ability");
        user.setAge(0);
        addUser(db, user);
        User user1 = new User();
        user1.setFirstName("Location");
        user1.setLastName("Wamf Phone features a new user interface, based upon Microsoft's Windows Phone 7 design system, codenamed Metro. The home screen, called the Start screen, is made up of Tiles. Tiles are links to applications, features, functions and individual items (such as contacts, web pages, applications or media items). Users can add, rearrange, or remove Tiles. Tiles are dynamic and update in real time - for example, the tile for an email account would display the number of unread messages or a Tile could display a live update of the weather.");
        user1.setAge(0);
        addUser(db, user1);
        User user11 = new User();
        user11.setFirstName("Friends");
        user11.setLastName("Friendship is about being what a hero of mine described as balcony people instead of basement people. Basement people are those who live in our minds, telling us we will never amount to anything, that we are doomed to fail and that we are royal screwups. Balcony people are those who are consistently cheering us on. Go for it, they say to our attempts to find our voice, to live in ever widening circles, to dare, to create, to break through our lives' sound barriers.");
        user11.setAge(0);
        addUser(db, user11);
        User user1111 = new User();
        user1111.setFirstName("Notifications");
        user1111.setLastName("A notification is a message, email, icon or another symbol that appears when an application wants you to pay attention. Notifications are a way to let you know that something new has happened so you don't miss anything that might be worth your attention and appears whether you are using an application or not. An application can use notifications to let you know things that are happening when you're not using it, so you don't miss important information or activity that's taking place in the app." );
        user1111.setAge(0);
        addUser(db, user1111);
        User user11111 = new User();
        user11111.setFirstName("Questions");
        user11111.setLastName("Questions are places in your mind where answers fit. If you haven’t asked the question, the answer has nowhere to go. It hits your mind and bounces right off. You have to ask the question — you have to want to know — in order to open up the space for the answer to fit");
        user11111.setAge(0);
        addUser(db, user11111);
        User user111 = new User();
        user111.setFirstName("Contact");
        user111.setLastName("The actual place a story happens is a little more straightforward. Most stories happen in several places, so when we identify the place of a story, the rule of thumb is to find the best way to describe where most of the story takes place. For example, in Star Wars the story is on many different planets; it would be most accurate to say the story takes place in space. In Romeo and Juliet, the characters interact in different houses and public places. It would be best to say the setting is in Verona, the city, instead of the Capulet or Montague family homes.");
        user111.setAge(0);
        addUser(db, user111);



        User user2 = new User();
        user2.setFirstName("Can I use the application when my device doesn't have connection?");
        user2.setLastName("\n" +
                "No, you can not use the application if you are not connected to the internet. All the service offered to you is based on the internet so you have to be connected to the internet to update your data.");
        user2.setAge(1);
        addUser(db, user2);

        User user3 = new User();
        user3.setFirstName("It is necessary to share my position?");
        user3.setLastName("Yes, you need to share your position to be found by the other friends of the group. You can not make yourself visible to others but you can not even view your friends' position.");
        user3.setAge(2);
        addUser(db, user3);

        User user4 = new User();
        user4.setFirstName("Can I see the position of my friends?");
        user4.setLastName("\n" +
                "Yes, you can see the position of all your friends belonging to the group. By clicking on the marker you can see the name of your friends and the distance from you. You can also select the distance for which you want to be notified of the presence of your friends.");
        user4.setAge(3);
        addUser(db, user4);

        User user6 = new User();
        user6.setFirstName("Can I block the notifications?");
        user6.setLastName("\n" +
                "Yes, you can block / allow notifications to your liking. You can receive system notifications and you can also receive notifications when your friends are close to you.");
        user6.setAge(4);
        addUser(db, user6);

        User user7 = new User();
        user7.setFirstName("Can I contact support?");
        user7.setLastName("\n" +
                "Yes, you can contact support at any time, highlighting your type of problem. We will reply as soon as possible.");
        user7.setAge(5);
        addUser(db, user7);

        User user8 = new User();
        user8.setFirstName("Can I setting the notification or more?");
        user8.setLastName("\n" +
                "Yes, you can change the notification settings in the NOTIFICATIONS section, you can manage (block / allow) both system notifications and those of nearby friends. In addition, you can block your visibility against friends, but you will not be able to see other friends");
        user8.setAge(6);
        addUser(db, user8);

        List<User> userList = db.userDao().getAll();
        Log.d(DatabaseInitializer.TAG, "Rows Count========: " + userList.size());
    }

    private static class PopulateDbAsync extends AsyncTask<Void, Void, Void> {

        private final AppDatabase mDb;

        PopulateDbAsync(AppDatabase db) {
            mDb = db;
        }

        @Override
        protected Void doInBackground(final Void... params) {
            //removeall(mDb);
            populateWithTestData(mDb);
            return null;
        }

    }
}