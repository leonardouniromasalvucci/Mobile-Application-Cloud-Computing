package com.example.leonardo.questionpage;

import android.app.Activity;
import android.app.Notification;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.login.LoginManager;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class ContactUs extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    // create an alert dialog
    AlertDialog alert;
    Spinner spin;
    TextView text;
    Button btnSend;
    LinearLayout l;

    private FirebaseDatabase database;

    public String object, textEmail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_us);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getcona();

        database = FirebaseDatabase.getInstance();


      /*  FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
        getSupportActionBar().setTitle("Contact us");
        getcon();
        btnSend = (Button)findViewById(R.id.button2);
        spin = (Spinner)findViewById(R.id.spinner1);
        text = (TextView)findViewById(R.id.editText7);



        l = (LinearLayout)findViewById(R.id.layx);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               // sendDataToFirebase();

                object = spin.getSelectedItem().toString();
                textEmail = text.getText().toString();

                Intent intent = new Intent(Intent.ACTION_SENDTO); // it's not ACTION_SEND
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, object);
                intent.putExtra(Intent.EXTRA_TEXT, textEmail);
                intent.setData(Uri.parse("mailto:leonardosalv4@gmail.com")); // or just "mailto:" for blank
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // this will make such that when user returns to your app, your app is displayed, instead of the email app.
                startActivity(intent);

                //Intent Intent = new Intent(getApplicationContext(), ContactUs.class);
               // startActivity(Intent);
                text.setText("");





            }
        });





    }

    private void sendDataToFirebase() {
        database = FirebaseDatabase.getInstance();
        DatabaseReference datRef = database.getReference("FAQ");//.child("test").setValue("khbkh");//.push();
        datRef.child("199287352439").setValue("My fourth question");
       // datRef.child("109287q37").child("latitude").setValue("12.4944");
       // datRef.child("1092873sq7").child("longitude").setValue("56.4944");
    }

    public void getcon(){
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            View promptView = layoutInflater.inflate(R.layout.input_dialogue_not_internet, null);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getApplicationContext());
            alertDialogBuilder.setView(promptView);
            alertDialogBuilder.setCancelable(false)
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            getcon();
                        }
                    });


           // alert = alertDialogBuilder.create();
            //alert.show();

        }

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.contact_us, menu);
        return true;
    }

  /*  @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            Intent Intent = new Intent(this, HomePage.class);
            startActivity(Intent);
        }  else if(id == R.id.friend){
            Intent Intent = new Intent(this, Friends.class);
            startActivity(Intent);

        } else if (id == R.id.notification) {
            Intent Intent = new Intent(this, com.example.leonardo.questionpage.Notification.class);
            startActivity(Intent);

        }  /*else if (id == R.id.manual) {
            Intent Intent = new Intent(this, Manual.class);
            startActivity(Intent);
        }*/ else if (id == R.id.questions) {
            Intent Intent = new Intent(this, Last.class);
            startActivity(Intent);
        }else if (id == R.id.contact) {
            Intent Intent = new Intent(this, ContactUs.class);
            startActivity(Intent);
        }else if (id == R.id.exit) {
            LoginManager.getInstance().logOut();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish(); System.exit(1);

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(
                view.getWindowToken(), 0);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        Log.v("òl", "i");
        InputMethodManager inputMethodManager =
                (InputMethodManager) getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(
                getCurrentFocus().getWindowToken(), 0);
        return true;
    }

    protected void showInputDialog3() {
        LayoutInflater layoutInflater = LayoutInflater.from(ContactUs.this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_not_internet, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ContactUs.this);
        alertDialogBuilder.setView(promptView);
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Try again", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        getcon();
                    }
                });
        AlertDialog alert = alertDialogBuilder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(final DialogInterface dialogInterface) {
                Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                button2.setTextSize(16);
                button2.setTextColor(Color.parseColor("#38b259"));

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        NetworkInfo netInfo = cm.getActiveNetworkInfo();
                        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
                            showInputDialog3();
                        }else{
                            dialogInterface.cancel();
                        }
                    }
                });
            }
        });
        alert.show();
    }
    public void getcona(){
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
            showInputDialog3();
        }else{
            Log.v("MESSAGE","Connection ok");
        }

    }



}
