package com.example.leonardo.questionpage;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewTreeObserver;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.login.LoginManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import static android.text.Html.fromHtml;

public class Manual extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

   /* ExpandableListView expandableListView1;
    ExpandableListAdapter expandableListAdapter1;
    List<String> expandableListTitle1;
    HashMap<String, List<String>> expandableListDetail1;*/
    public ArrayList<Manu> menus;
    public LinearLayout lay, lay2;
    ScrollView scrool;
    TextView textView1;
    Context cc;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("Manual 1.0");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        cc=this;

     /*   DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);*/






        lay = (LinearLayout)findViewById(R.id.layManu);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lay.setOrientation(LinearLayout.VERTICAL);

        lay2 = (LinearLayout)findViewById(R.id.all);
        LinearLayout.LayoutParams params2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lay2.setOrientation(LinearLayout.VERTICAL);







        menus = new ArrayList<>();




        List<User> l = AppDatabase.getAppDatabase(cc).userDao().getAllManual();
        for(int i=0; i<l.size(); i++){
            menus.add(new Manu(l.get(i).getFirstName(),i,l.get(i).getLastName()));
          //  Log.v("USER", "_________________________________");
          //  Log.v("USER", i+":"+l.get(i).getFirstName());
          //  Log.v("USER", "__________________________________");
        }


     /*   menus.add(new Manu("Introduction",0,"Achieving complex and difficult goals requires focus, long-term diligence and effort (see Goal pursuit). Success in any field requires forgoing excuses and justifications for poor performance or lack of adequate planning; in short, success requires emotional maturity. The measure of belief that people have in their ability to achieve a personal goal also affects that achievement."));
        menus.add(new Manu("General",1,"The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant "));
        menus.add(new Manu("Position",2,"The genrqal info is very importntant The genrqal info is very importntant  The genrqal info is very importntant "));
        menus.add(new Manu("Friends",3,"The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant "));
        menus.add(new Manu("Settings",4,"The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant "));
        menus.add(new Manu("Privacy",5,"The genrqal info is very importntant The genrqal info is very importntant  The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant "));
        menus.add(new Manu("Notifications",6,"The genrqal info is very importntant The genrqal info is very importntant The genrqal info is very importntant "));
        menus.add(new Manu("Reports",7,"The genrqal info is very importntant The genrqal info is very importntant  The genrqal info is very importntant "));
*/

        for(int i=0; i<menus.size(); i++){
            TextView textView = new TextView(this);
            textView.setText(menus.get(i).categoria);
            textView.setLayoutParams(params);
            textView.setTextColor(Color.parseColor("#900e3f73"));
            textView.setId(menus.get(i).ids);
            textView.setTextSize(18f);
            textView.setTypeface(Typeface.DEFAULT_BOLD);
            textView.setPadding(15,35,0,35);
            textView.setCompoundDrawablePadding(5);
            lay.addView(textView);
            View v = new View(this);
            v.setLayoutParams(params);
            v.setBackgroundColor(Color.parseColor("#e1e1e1"));
            v.setMinimumHeight(2);
            lay.addView(v);

        }

        for(int i=0; i<menus.size(); i++){
            textView1 = new TextView(this);
            textView1.setText(menus.get(i).categoria.toUpperCase());
            textView1.setLayoutParams(params2);
            textView1.setTextColor(Color.parseColor("#494949"));
            textView1.setTextSize(18f);
            textView1.setTypeface(Typeface.DEFAULT_BOLD);

            textView1.setId(menus.get(i).ids);
            textView1.setPadding(5,25,5,6);
            lay2.addView(textView1);

            TextView textView2 = new TextView(this);
            textView2.setText(menus.get(i).descrizione);
            textView2.setLayoutParams(params2);
            textView2.setTextColor(Color.parseColor("#494949"));
            textView2.setTextSize(16f);
            textView2.setId(menus.get(i).ids+11);
            textView2.setPadding(5,5,5,45);
            lay2.addView(textView2);

            View v = new View(this);
            v.setLayoutParams(params2);
            v.setBackgroundColor(Color.parseColor("#e1e1e1"));
            v.setMinimumHeight(2);
            v.setPadding(5,5,5,185);
            lay2.addView(v);



        }


        View v = null;
        for(int i=0; i<lay.getChildCount(); i++) {
            v = lay.getChildAt(i);
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    scrool.scrollTo(0,0);

                    View v2 = null;
                    for(int ii=0; ii<lay2.getChildCount(); ii++) {
                        v2 = lay2.getChildAt(ii);
                        if (v2.getId() == v.getId()) {
                            int[] p = {0,0};
                            Log.v("messsage"," "+v.getId()+"ii "+ v2.getId());
                            v2.getLocationInWindow(p);
                            scrool.scrollTo(p[0],(p[1]-180));



                        }
                    }
                }
            });
           // Log.v("messsage","i: "+v.getId());
        }





       /* expandableListView1 = (ExpandableListView) findViewById(R.id.expandableListView1);
      //  expandableListView1.setGroupIndicator(null);
        expandableListDetail1 = ExpandableListDataPump1.getData();
        expandableListTitle1 = new ArrayList<String>(expandableListDetail1.keySet());
        expandableListAdapter1 = new CustomExpandableListAdapter1(this, expandableListTitle1, expandableListDetail1);
        expandableListView1.setAdapter(expandableListAdapter1);
        expandableListView1.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                Toast.makeText(getApplicationContext(),
                        expandableListTitle1.get(groupPosition) + " List Expanded.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        expandableListView1.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
                Toast.makeText(getApplicationContext(),
                        expandableListTitle1.get(groupPosition) + " List Collapsed.",
                        Toast.LENGTH_SHORT).show();

            }
        });

        expandableListView1.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        expandableListTitle1.get(groupPosition)
                                + " -> "
                                + expandableListDetail1.get(
                                expandableListTitle1.get(groupPosition)).get(
                                childPosition), Toast.LENGTH_SHORT
                ).show();
                return false;
            }
        });*/
        final FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.floating);
        fab.setVisibility(View.INVISIBLE);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                scrool.scrollTo(0,0);
            }
        });

        scrool = (ScrollView)findViewById(R.id.scr);
        scrool.getViewTreeObserver().addOnScrollChangedListener(new ViewTreeObserver.OnScrollChangedListener() {
            @Override
            public void onScrollChanged() {
                int scrollY = scrool.getScrollY(); // For ScrollView
                int scrollX = scrool.getScrollX(); // For HorizontalScrollView
                if(scrollY>1000){
                    fab.setVisibility(View.VISIBLE);

                }else{
                    fab.setVisibility(View.INVISIBLE);

                }
                // DO SOMETHING WITH THE SCROLL COORDINATES
            }
        });
    }





    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(getApplicationContext(), Last.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }


    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menux, menu);
        //SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        android.support.v7.widget.SearchView searchView = (android.support.v7.widget.SearchView) menu.findItem(R.id.menu_search).getActionView();
        // searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setQueryHint("Search info...");
        //searchView.setMaxWidth(220);
        searchView.setIconified(true);
        searchView.setOnQueryTextListener(new android.support.v7.widget.SearchView.OnQueryTextListener() {
            int inc=0;

            List<Integer> l = new ArrayList<>();

            @Override
            public boolean onQueryTextSubmit(String query) {
                inc++;
                if(inc==l.size()){
                    inc=0;
                }

                scrool.scrollTo(0,0);

                if(l.size()>0){
                    View v3 = null;
                //    Log.v("mess","ssss"+l.get(0)+"\n");
                    for (int ii = 0; ii < lay2.getChildCount(); ii++) {
                        v3 = lay2.getChildAt(ii);
                        if (v3.getId() == l.get(inc)) {
                            int[] p = {0, 0};
                            v3.getLocationOnScreen(p);
                            scrool.scrollTo(p[0], p[1]-320);
                        }
                    }

                }else{
                    scrool.scrollTo(0,0);
                }


                /*    View v2 = null;
                    for (int ii = 0; ii < lay2.getChildCount(); ii++) {
                        v2 = lay2.getChildAt(ii);
                        if (v2.getId() == inc) {
                            int[] p = {0, 0};
                            v2.getLocationOnScreen(p);
                            scrool.scrollTo(p[0], p[1]);
                        }
                    }*/


                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                l.clear();

                    for (int z = 0; z < menus.size(); z++) {


                        if(menus.get(z).getDescrizione().contains(newText)) {
                            View v2 = null;
                            for (int ii = 0; ii < lay2.getChildCount(); ii++) {
                                v2 = lay2.getChildAt(ii);
                                if (v2.getId() == menus.get(z).getIds()+11) {
                                    TextView t = (TextView)v2;
                                    String classe = t.getText().toString();
                                    Spannable spannable = new SpannableString(classe);
                                    spannable.setSpan(new ForegroundColorSpan(Color.BLUE), classe.indexOf(newText), classe.indexOf(newText) + newText.length(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                                    t.setText(spannable);
                                }
                            }
                            l.add(menus.get(z).getIds());




                            if (v2.getId() == l.get(0)) {
                                int[] p = {0, 0};
                                v2.getLocationOnScreen(p);
                                scrool.scrollTo(p[0], p[1]-320);
                            }



                        }else{

                            View v2 = null;
                            for (int ii = 0; ii < lay2.getChildCount(); ii++) {
                                v2 = lay2.getChildAt(ii);
                                if (v2.getId() == menus.get(z).getIds()+11) {
                                    TextView t = (TextView)v2;
                                    String classe = t.getText().toString();
                                    Spannable spannable = new SpannableString(classe);
                                    spannable.setSpan(new ForegroundColorSpan(Color.parseColor("#494949")),0, classe.length(),Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                                    t.setText(spannable);
                                   // scrool.scrollTo(0,0);


                                }
                            }
                        }


                    }

                for(int k=0;k<l.size();k++){
                    Log.v("mess","kkkkkk"+l.get(k)+"\n");
                }
                scrool.scrollTo(0,0);

                if(l.size()>0){
                    View v3 = null;
                    Log.v("mess","ssss"+l.get(0)+"\n");
                    for (int ii = 0; ii < lay2.getChildCount(); ii++) {
                        v3 = lay2.getChildAt(ii);
                        if (v3.getId() == l.get(0)) {
                            int[] p = {0, 0};
                            v3.getLocationOnScreen(p);
                            Log.v("mess","==="+p[0]+"==="+p[1]);
                            scrool.scrollTo(p[0], p[1]-320);
                        }
                    }

                }else{
                    scrool.scrollTo(0,0);
                }


             /*   View v3 = null;
                Log.v("mess","ssss"+l.get(0)+"\n");
                for (int ii = 0; ii < lay2.getChildCount(); ii++) {
                    v3 = lay2.getChildAt(ii);
                    if (v3.getId() == l.get(0)) {
                        int[] p = {0, 0};
                        v3.getLocationOnScreen(p);
                        scrool.scrollTo(p[0], p[1]-320);
                    }
                }*/

              /*  if(newText.length()==0){
                    scrool.scrollTo(0,0);
                }*/



                return true;
            }
        });

        return true;
    }


   /* @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }*/

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            Intent Intent = new Intent(this, HomePage.class);
            startActivity(Intent);
        } else if (id == R.id.notification) {
            Intent Intent = new Intent(this, Notification.class);
            startActivity(Intent);

        }else if (id == R.id.friend) {
            Intent Intent = new Intent(this, Friends.class);
            startActivity(Intent);

        }/* else if (id == R.id.manual) {
            Intent Intent = new Intent(this, Manual.class);
            startActivity(Intent);
        }*/ else if (id == R.id.questions) {
            Intent Intent = new Intent(this, MainActivity.class);
            startActivity(Intent);
        }else if (id == R.id.contact) {
            Intent Intent = new Intent(this, ContactUs.class);
            startActivity(Intent);
        }else if (id == R.id.exit) {
            LoginManager.getInstance().logOut();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            System.exit(1);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
