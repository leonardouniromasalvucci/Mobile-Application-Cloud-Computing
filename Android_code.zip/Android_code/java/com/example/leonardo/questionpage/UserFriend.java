package com.example.leonardo.questionpage;

public class UserFriend {

    String IdFacebook;
    int IdInc;
    String Nome;
    boolean Checked;

    public UserFriend(String IdFacebook, int IdInc, String Nome, boolean Checked){
        this.IdFacebook = IdFacebook;
        this.IdInc = IdInc;
        this.Nome = Nome;
        this.Checked = Checked;
    }

    public String getIdFacebook(){
        return this.IdFacebook;
    }
    public int getIdInc(){
        return this.IdInc;
    }
    public String getNome(){
        return this.Nome;
    }
    public boolean getCheck(){
        return this.Checked;
    }
    public void setChexked(boolean value){
        this.Checked = value;
    }

}
