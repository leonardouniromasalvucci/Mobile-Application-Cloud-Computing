package com.example.leonardo.questionpage;

import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.login.LoginManager;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

public class MainActivity extends AppCompatActivity  implements NavigationView.OnNavigationItemSelectedListener{

    //private android.support.v7.widget.SearchView searchs;
    ExpandableListView expandableListView;
    ExpandableListAdapter expandableListAdapter;
    List<String> expandableListTitle;
    HashMap<String, List<String>> expandableListDetail;
    SearchView simpleSearchView;
    ArrayList<String> list =  new ArrayList<String>();
    ArrayList<String> l = new ArrayList<>();
    public boolean connected = false;
    LayoutInflater inflater;
    View rowView,rowView1;
    LinearLayout loin;
    Context cc;

    ExpandableListView expandableListView1;
    ExpandableListAdapter expandableListAdapter1;
    List<String> expandableListTitle1;
    HashMap<String, List<String>> expandableListDetail1;

    FloatingActionButton fab;

    private FirebaseDatabase database;
     DatabaseReference datRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        cc=this;
      /*  DatabaseInitializer.populateAsync(AppDatabase.getAppDatabase(this));

        List<User> l = AppDatabase.getAppDatabase(cc).userDao().getAll();
        for(int i=0; i<l.size(); i++){
            Log.v("USER", "_________________________________");
            Log.v("USER", i+":"+l.get(i).getFirstName());
            Log.v("USER", "__________________________________");
        }*/


        loin = (LinearLayout) findViewById(R.id.questionlay);
        inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        rowView = inflater.inflate(R.layout.answer, null);
        rowView1 = inflater.inflate(R.layout.general, null);
        loin.addView(rowView1);



        setTitle("Frequent question"); // for set actionbar title
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        expandableListView = (ExpandableListView) rowView1.findViewById(R.id.expandableListView);
        expandableListDetail = getData();
        expandableListTitle = new ArrayList<String>(expandableListDetail.keySet());
        Collections.sort(expandableListTitle);


        expandableListAdapter = new CustomExpandableListAdapter(this, expandableListTitle, expandableListDetail);


        expandableListView.setAdapter(expandableListAdapter);
        expandableListView.setTextFilterEnabled(true);


        expandableListView1 = (ExpandableListView) rowView.findViewById(R.id.expandableListViewX);
        expandableListDetail1 = getData1();
        expandableListTitle1 = new ArrayList<String>(expandableListDetail1.keySet());
        Collections.sort(expandableListTitle1);

        expandableListAdapter1 = new CustomExpandableListAdapter1(this, expandableListTitle1, expandableListDetail1);


        expandableListView1.setAdapter(expandableListAdapter1);
        expandableListView1.setTextFilterEnabled(true);

        for(int i=0; i < expandableListAdapter1.getGroupCount(); i++) {
            expandableListView1.expandGroup(i);
        }







        expandableListView1.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
               /* Toast.makeText(getApplicationContext(),
                        expandableListTitle1.get(groupPosition) + " List Expanded.",
                        Toast.LENGTH_SHORT).show();*/
            }
        });

        expandableListView1.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
               /* Toast.makeText(getApplicationContext(),
                        expandableListTitle1.get(groupPosition) + " List Collapsed.",
                        Toast.LENGTH_SHORT).show();*/

            }
        });









        expandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
               /* Toast.makeText(
                        getApplicationContext(),
                        expandableListTitle.get(groupPosition)
                                + " -> "
                                + expandableListDetail.get(
                                expandableListTitle.get(groupPosition)).get(
                                childPosition), Toast.LENGTH_SHORT
                ).show();*/

                Intent intent = new Intent(getApplicationContext(), GeneralQuestion.class);
                Bundle b = new Bundle();
                b.putInt("key", groupPosition);
                intent.putExtras(b); //Put your id to your next Intent
                startActivity(intent);
                finish();
                return false;
            }
        });


        fab = (FloatingActionButton) findViewById(R.id.floating);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showInputDialog();
            }
        });






    }

    /*private void sendDataToFirebase(String id, String FAQ) {
        database = FirebaseDatabase.getInstance();
        DatabaseReference datRef = database.getReference("FAQ");//.child("test").setValue("khbkh");//.push();
        datRef.child(id).setValue(FAQ);
        // datRef.child("109287q37").child("latitude").setValue("12.4944");
        // datRef.child("1092873sq7").child("longitude").setValue("56.4944");
    }*/


    public void getTesto(View v){
        TextView t = (TextView)v;
        String s = t.getText().toString();
        Toast.makeText(getApplicationContext(),""+s,Toast.LENGTH_SHORT).show();
    }

    protected void showInputDialog() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            // get prompts.xml view
            LayoutInflater layoutInflater = LayoutInflater.from(MainActivity.this);
            View promptView = layoutInflater.inflate(R.layout.input_dialog, null);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
            alertDialogBuilder.setView(promptView);

            final EditText editText = (EditText) promptView.findViewById(R.id.edittext);
            // setup a dialog window
            alertDialogBuilder.setCancelable(false)
                    .setPositiveButton("Send", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {//.child("test").setValue("khbkh");//.push();

                            showInputDialog1();
                        }
                    })
                    .setNegativeButton("Cancel",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });

            // create an alert dialog
            AlertDialog alert = alertDialogBuilder.create();
            alert.setOnShowListener(new DialogInterface.OnShowListener() {

                @Override
                public void onShow(final DialogInterface dialogInterface) {

                    //Button button = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEUTRAL);
                    Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                    Button button3 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEGATIVE);
                    button3.setTextSize(16);
                    button2.setTextSize(16);
                    button2.setTextColor(Color.parseColor("#38b259"));
                  //  button2.setBackgroundColor(Color.parseColor("#86b950"));
                  //  button3.setPadding(12,12,112,12);


                    button3.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {
                            dialogInterface.cancel();
                        }
                    });

                    button2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref5", MODE_PRIVATE);
                            int name = pref.getInt("id_values", 0);
                            String vid = String.valueOf(name);
                            sendDataToFirebase(vid,editText.getText().toString());



                            showInputDialog1();
                            dialogInterface.cancel();
                        }
                    });
                }
            });
            alert.show();

        } else {
            LayoutInflater layoutInflater = LayoutInflater.from(MainActivity.this);
            View promptView = layoutInflater.inflate(R.layout.input_dialogue_not_internet, null);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
            alertDialogBuilder.setView(promptView);

            final TextView editText = (TextView) promptView.findViewById(R.id.textView);
            final TextView editText2 = (TextView) promptView.findViewById(R.id.textView2);
            // setup a dialog window
            alertDialogBuilder.setCancelable(false)
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });


            // create an alert dialog
            AlertDialog alert = alertDialogBuilder.create();
            alert.setOnShowListener(new DialogInterface.OnShowListener() {

                @Override
                public void onShow(final DialogInterface dialogInterface) {

                    //Button button = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEUTRAL);
                    Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                   // Button button3 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEGATIVE);
                  //  button3.setTextSize(16);
                    button2.setTextSize(16);
                    button2.setTextColor(Color.parseColor("#38b259"));
                    //button2.setTextColor(Color.parseColor("#ffffff"));
                    //button2.setBackgroundColor(Color.parseColor("#494949"));
                    //  button3.setPadding(12,12,112,12);


                   /* button.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {

                        }
                    });*/

                    button2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialogInterface.cancel();
                        }
                    });
                }
            });

            alert.show();

        }



    }

    public HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();




        List<String> general = new ArrayList<String>();
        // friends.add("Where is my friends?");
        // friends.add("Blacklist");
        // friends.add("Range visbility");


        List<String> location = new ArrayList<String>();
        // location.add("Where is my place?");
        // location.add("Block location");
        // location.add("Near me");
        // location.add("Why don't see me?"

        List<String> friends = new ArrayList<String>();
        // location.add("Where is my place?");
        // location.add("Block location");
        // location.add("Near me");
        // location.add("Why don't see me?"



        List<String> notifications = new ArrayList<String>();
        //  notifications.add("Where is my friends?");
        //  notifications.add("Blacklist");
        //  notifications.add("Range visbility");

        List<String> contact = new ArrayList<String>();
        //  notifications.add("Where is my friends?");
        //  notifications.add("Blacklist");
        //  notifications.add("Range visbility");

        List<String> setting = new ArrayList<String>();
        //  notifications.add("Where is my friends?");
        //  notifications.add("Blacklist");
        //  notifications.add("Range visbility");
        //GeneralQuestion gg = new GeneralQuestion();
        ArrayList<Answer> list_ans = new ArrayList<>();
        List<User> l = AppDatabase.getAppDatabase(cc).userDao().getAllFAQ();
        for(int i=0; i<l.size(); i++){
            if(l.get(i).getAge()==1){
                list_ans.add(new Answer(2,"General",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==2){
                list_ans.add(new Answer(3,"Location",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==3){
                list_ans.add(new Answer(1,"Friends",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==4){
                list_ans.add(new Answer(4,"Notifications",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==5){
                list_ans.add(new Answer(0,"Contact",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==6){
                list_ans.add(new Answer(5,"Setting",l.get(i).getFirstName(),l.get(i).getLastName()));
            }

        }


        //ArrayList<Answer> list_ans = Answer.getQuestionAnswer();
        //ArrayList<Answer> list_ans =
        for(int i=0; i<list_ans.size(); i++){
            if(list_ans.get(i).getCategory()=="General"){
                general.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }else if(list_ans.get(i).getCategory()=="Location"){
                location.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }
            else if(list_ans.get(i).getCategory()=="Friends"){
                friends.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }
            else if(list_ans.get(i).getCategory()=="Notifications"){
                notifications.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }else if(list_ans.get(i).getCategory()=="Setting"){
                setting.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }else if(list_ans.get(i).getCategory()=="Contact"){
                contact.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }


        }


        expandableListDetail.put("General", general);
        expandableListDetail.put("Location", location);
        expandableListDetail.put("Friends", friends);
        expandableListDetail.put("Notifications", notifications);
        expandableListDetail.put("Setting", setting);
        expandableListDetail.put("Contact", contact);



        return expandableListDetail;
    }

    public HashMap<String, List<String>> getData1() {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();




      /*  List<String> general = new ArrayList<String>();
        general.add("Traduzioni in contesto pergg in inglese-italiano da Reverso Context: text message, text messages, text as a whole, the original text, new text....");

        List<String> general1 = new ArrayList<String>();
        general1.add("Traduzioni in contesto pergg in inglese-italiano da Reverso Context: text message, text messages, text as a whole, the original text, new text....");

        List<String> general2 = new ArrayList<String>();
        general2.add("Traduzioni in contesto pergg in inglese-italiano da Reverso Context: text message, text messages, text as a whole, the original text, new text....");

        List<String> general3 = new ArrayList<String>();
        general3.add("Traduzioni in contesto pergg in inglese-italiano da Reverso Context: text message, text messages, text as a whole, the original text, new text....");

*/

      //  ArrayList<Answer> list_ans = Answer.getQuestionAnswer();
        ArrayList<Answer> list_ans = new ArrayList<>();
        List<User> l = AppDatabase.getAppDatabase(cc).userDao().getAllFAQ();
        for(int i=0; i<l.size(); i++){
            if(l.get(i).getAge()==1){
                list_ans.add(new Answer(2,"General",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==2){
                list_ans.add(new Answer(3,"Location",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==3){
                list_ans.add(new Answer(1,"Friends",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==4){
                list_ans.add(new Answer(4,"Notifications",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==5){
                list_ans.add(new Answer(0,"Contact",l.get(i).getFirstName(),l.get(i).getLastName()));
            }else if(l.get(i).getAge()==6){
                list_ans.add(new Answer(5,"Setting",l.get(i).getFirstName(),l.get(i).getLastName()));
            }

        }

        for(int i=0; i<list_ans.size(); i++){
            List<String> general = new ArrayList<String>();
            general.add(list_ans.get(i).getResponse());
            expandableListDetail.put(list_ans.get(i).getQuestion(), general);

        }
   /*     expandableListDetail.put("Where si my place?", general);
        expandableListDetail.put("How find my friends?", general1);
        expandableListDetail.put("Can i block notifications?", general2);
        expandableListDetail.put("Where is my place?", general3);*/

        return expandableListDetail;
    }

    @Override
    protected void onDestroy() {
        AppDatabase.destroyInstance();
        super.onDestroy();
    }

    protected final void sendDataToFirebase(String id, String FAQ) {
        database = FirebaseDatabase.getInstance();
        DatabaseReference datRef = database.getReference("FAQ");//.child("test").setValue("khbkh");//.push();
        datRef.child(id).setValue(FAQ);
        // datRef.child("109287q37").child("latitude").setValue("12.4944");
        // datRef.child("1092873sq7").child("longitude").setValue("56.4944");
    }

    protected void showInputDialog1() {

        // get prompts.xml view
        LayoutInflater layoutInflater = LayoutInflater.from(MainActivity.this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_2, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);
        alertDialogBuilder.setView(promptView);

        final TextView editText = (TextView) promptView.findViewById(R.id.textView);
        final TextView editText2 = (TextView) promptView.findViewById(R.id.textView2);
        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });


        // create an alert dialog
        AlertDialog alert = alertDialogBuilder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(final DialogInterface dialogInterface) {

                //Button button = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEUTRAL);
                Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
               // Button button3 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEGATIVE);
              //  button3.setTextSize(16);
                button2.setTextSize(16);
                button2.setTextColor(Color.parseColor("#38b259"));
                //button2.setTextColor(Color.parseColor("#494949"));
                //button2.setBackgroundColor(Color.parseColor("#f0f0f0"));
                //  button3.setPadding(12,12,112,12);


                   /* button.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View view) {

                        }
                    });*/

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialogInterface.cancel();
                    }
                });
            }
        });
        alert.show();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menux, menu);
        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        android.support.v7.widget.SearchView searchView = (android.support.v7.widget.SearchView) menu.findItem(R.id.menu_search).getActionView();
      /*  android.support.v7.widget.SearchView.SearchAutoComplete mSearchAutoComplete;
        mSearchAutoComplete = (android.support.v7.widget.SearchView.SearchAutoComplete) searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        mSearchAutoComplete.setDropDownBackgroundResource(R.drawable.ic_apps_black_24dp);
        mSearchAutoComplete.setDropDownAnchor(R.id.menu_search);
     //   mSearchAutoComplete.setThreshold(0);
        ArrayList<String> searchItems = new ArrayList<String>();
        searchItems.add("ci siamo");
        searchItems.add("dove sei");
        searchItems.add("dai bello");
        searchItems.add("vamosss");


        ArrayAdapter<String> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_list_item_1, searchItems);
        mSearchAutoComplete.setAdapter(adapter);*/

        /*final android.support.v7.widget.SearchView.SearchAutoComplete searchAutoComplete = (android.support.v7.widget.SearchView.SearchAutoComplete)searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        searchAutoComplete.setBackgroundColor(Color.parseColor("#f0f0f0"));
        searchAutoComplete.setTextColor(Color.parseColor("#494949"));
        searchAutoComplete.setDropDownBackgroundResource(android.R.color.background_light);
        String dataArr[] = {"Apple\ngergegh" , "Amazon" , "Amd", "Microsoft\nI want to display 3 fields from the database, but I do not know about ", "Microwave\nI want to display 3 fields from the database, but I do not know about r", "MicroNews\nI want to display 3 fields from the database, but I do not know about ", "Intel", "Intelligence"};
        ArrayAdapter<String> newsAdapter = new ArrayAdapter<String>(this, R.layout.autocom, dataArr);
        searchAutoComplete.setAdapter(newsAdapter);*/



        // searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setQueryHint("Search in the questions...");
        searchView.setOnQueryTextListener(new android.support.v7.widget.SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                loin.removeAllViews();
                fab.setVisibility(View.INVISIBLE);
                loin.addView(rowView);


             /*   for (Map.Entry<String, List<String>> entry : expandableListDetail1.entrySet()) {
                    String key = entry.getKey();
                    List<String> value = entry.getValue();
                    for(String aString : value){
                        l.add(aString);
                        System.out.println("key : " + key + " value : " + aString);
                    }
                }

                for(int i=0; i<l.size(); i++){
                    Log.v("m: "+i+"="+l.size()+"//","__"+l.get(i));


                }
*/
                expandableListTitle1 = new ArrayList<String>(expandableListDetail1.keySet());
                Collections.sort(expandableListTitle1);
               // Collections.sort(l);
                list.clear();
                for(int i=0; i<expandableListTitle1.size(); i++){
                    if(expandableListTitle1.get(i).toLowerCase().contains(newText.toLowerCase())){
                        list.add(expandableListTitle1.get(i));
                    }
                }


                expandableListAdapter1 = new CustomExpandableListAdapter1(cc, list, expandableListDetail1);
                expandableListView1.setAdapter(expandableListAdapter1);

                for(int i=0; i < expandableListAdapter1.getGroupCount(); i++) {
                    expandableListView1.expandGroup(i);
                }

                if(newText.length()==0){
                    loin.removeAllViews();
                    loin.addView(rowView1);
                    fab.setVisibility(View.VISIBLE);
                }

                return false;
            }
        });

        return true;
    }





    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(getApplicationContext(), Last.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            Intent Intent = new Intent(this, HomePage.class);
            startActivity(Intent);
        }  else if(id == R.id.friend){
            Intent Intent = new Intent(this, Friends.class);
            startActivity(Intent);

        } else if (id == R.id.notification) {
            Intent Intent = new Intent(this, com.example.leonardo.questionpage.Notification.class);
            startActivity(Intent);

        }/* else if (id == R.id.manual) {
            Intent Intent = new Intent(this, Manual.class);
            startActivity(Intent);
        }*/ else if (id == R.id.questions) {
            Intent Intent = new Intent(this, Last.class);
            startActivity(Intent);
        }else if (id == R.id.contact) {
            Intent Intent = new Intent(this, ContactUs.class);
            startActivity(Intent);
        }else if (id == R.id.exit) {
            LoginManager.getInstance().logOut();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            System.exit(1);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

}
