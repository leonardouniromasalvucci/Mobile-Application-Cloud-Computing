package com.example.leonardo.questionpage;

import android.content.Context;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExpandableListDataPump extends GeneralQuestion{


    public static HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();




        List<String> general = new ArrayList<String>();
       // friends.add("Where is my friends?");
       // friends.add("Blacklist");
       // friends.add("Range visbility");


        List<String> location = new ArrayList<String>();
       // location.add("Where is my place?");
       // location.add("Block location");
       // location.add("Near me");
       // location.add("Why don't see me?"

        List<String> friends = new ArrayList<String>();
        // location.add("Where is my place?");
        // location.add("Block location");
        // location.add("Near me");
        // location.add("Why don't see me?"



        List<String> notifications = new ArrayList<String>();
      //  notifications.add("Where is my friends?");
      //  notifications.add("Blacklist");
      //  notifications.add("Range visbility");

        List<String> contact = new ArrayList<String>();
        //  notifications.add("Where is my friends?");
        //  notifications.add("Blacklist");
        //  notifications.add("Range visbility");

        List<String> setting = new ArrayList<String>();
        //  notifications.add("Where is my friends?");
        //  notifications.add("Blacklist");
        //  notifications.add("Range visbility");
        //GeneralQuestion gg = new GeneralQuestion();


        ArrayList<Answer> list_ans = Answer.getQuestionAnswer();
       // ArrayList<Answer> list_ans =
        for(int i=0; i<list_ans.size(); i++){
            if(list_ans.get(i).getCategory()=="General"){
                general.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }else if(list_ans.get(i).getCategory()=="Location"){
                location.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }
            else if(list_ans.get(i).getCategory()=="Friends"){
                friends.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }
            else if(list_ans.get(i).getCategory()=="Notifications"){
                notifications.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }else if(list_ans.get(i).getCategory()=="Setting"){
                setting.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }else if(list_ans.get(i).getCategory()=="Contact"){
                contact.add(list_ans.get(i).getQuestion());
                //expandableListDetail.put(list_ans.get(i).getCategory(), general);
            }


        }


        expandableListDetail.put("General", general);
        expandableListDetail.put("Location", location);
        expandableListDetail.put("Friends", friends);
        expandableListDetail.put("Notifications", notifications);
        expandableListDetail.put("Setting", setting);
        expandableListDetail.put("Contact", contact);



        return expandableListDetail;
    }

    public ArrayList<Answer> getDatas(){
        ArrayList<Answer> list_ans = new ArrayList<>();
        List<User> l = AppDatabase.getAppDatabase(cc).userDao().getAllFAQ();
        for(int i=0; i<l.size(); i++){
           // list_ans.add(new Answer(i,"General",l.get(i).getFirstName(),l.get(i).getLastName()));
        }
        return list_ans;
    }
}

