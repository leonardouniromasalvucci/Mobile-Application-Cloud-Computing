package com.example.leonardo.questionpage;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExpandableListDataPump1 extends GeneralQuestion{

    public static HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableListDetail = new HashMap<String, List<String>>();




      /*  List<String> general = new ArrayList<String>();
        general.add("Traduzioni in contesto pergg in inglese-italiano da Reverso Context: text message, text messages, text as a whole, the original text, new text....");

        List<String> general1 = new ArrayList<String>();
        general1.add("Traduzioni in contesto pergg in inglese-italiano da Reverso Context: text message, text messages, text as a whole, the original text, new text....");

        List<String> general2 = new ArrayList<String>();
        general2.add("Traduzioni in contesto pergg in inglese-italiano da Reverso Context: text message, text messages, text as a whole, the original text, new text....");

        List<String> general3 = new ArrayList<String>();
        general3.add("Traduzioni in contesto pergg in inglese-italiano da Reverso Context: text message, text messages, text as a whole, the original text, new text....");

*/

        ArrayList<Answer> list_ans = Answer.getQuestionAnswer();
        for(int i=0; i<list_ans.size(); i++){
            List<String> general = new ArrayList<String>();
            general.add(list_ans.get(i).getResponse());
            expandableListDetail.put(list_ans.get(i).getQuestion(), general);

        }
   /*     expandableListDetail.put("Where si my place?", general);
        expandableListDetail.put("How find my friends?", general1);
        expandableListDetail.put("Can i block notifications?", general2);
        expandableListDetail.put("Where is my place?", general3);*/

        return expandableListDetail;
    }
    public ArrayList<Answer> getDatas(){
        ArrayList<Answer> list_ans = new ArrayList<>();
        List<User> l = AppDatabase.getAppDatabase(cc).userDao().getAllFAQ();
        for(int i=0; i<l.size(); i++){
         //   list_ans.add(new Answer(i,"General",l.get(i).getFirstName(),l.get(i).getLastName()));
        }
        return list_ans;
    }
}
