package com.example.leonardo.questionpage;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.preference.PreferenceManager;
import android.support.design.widget.NavigationView;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ChooseCode extends AppCompatActivity {
    int id_user=0;
    int idd=0;
    int ff=0;
    String name="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_code);

        Bundle b = getIntent().getExtras();
        Bundle b1 = getIntent().getExtras();
        Bundle b2 = getIntent().getExtras();
        if(b != null) {
            if(b.getInt("key")!=0){
                id_user = b.getInt("key");
                Log.v("TAG", ""+ id_user);
                savePreferences2("id_v",id_user);
            }
        }
        if(b2 != null) {
            if(b2.getString("name")!=""){
                name = b.getString("name");
                Log.v("TAG", ""+ name);
            }
        }
        if(b1 != null) {
            ff = b1.getInt("log");
        }
        loadSavedPreferences2();
        showInputDialog();
    }

    protected void showInputDialog() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            LayoutInflater layoutInflater = LayoutInflater.from(ChooseCode.this);
            View promptView = layoutInflater.inflate(R.layout.input_dialogue_5, null);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ChooseCode.this);
            alertDialogBuilder.setView(promptView);

            final EditText editText = (EditText) promptView.findViewById(R.id.edittext2);
            alertDialogBuilder.setCancelable(false)
                    .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                        }
                    })
            ;

            // create an alert dialog
            AlertDialog alert = alertDialogBuilder.create();
            alert.setOnShowListener(new DialogInterface.OnShowListener() {

                @Override
                public void onShow(final DialogInterface dialogInterface) {
                    Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                    button2.setTextSize(16);
                    button2.setTextColor(Color.parseColor("#38b259"));

                    button2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            Intent Intent = new Intent(getApplicationContext(), HomePage.class);
                            Bundle b = new Bundle();
                            b.putInt("key", idd);
                            Intent.putExtras(b); //Put your id to your next Intent
                            Bundle b1 = new Bundle();
                            b1.putString("key_code", editText.getText().toString());
                            Intent.putExtras(b1); //Put your id to your next Intent
                            Bundle b2 = new Bundle();
                            b2.putInt("ff", 9);
                            Intent.putExtras(b2); //Put your id to your next Intent
                            Bundle b3 = new Bundle();
                            b3.putString("name", name);
                            Intent.putExtras(b3); //Put your id to your next Intent
                            startActivity(Intent);
                            dialogInterface.cancel();
                        }
                    });
                }
            });
            alert.show();

        } else {
            LayoutInflater layoutInflater = LayoutInflater.from(ChooseCode.this);
            View promptView = layoutInflater.inflate(R.layout.input_dialogue_not_internet, null);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(ChooseCode.this);
            alertDialogBuilder.setView(promptView);

            final TextView editText = (TextView) promptView.findViewById(R.id.textView);
            final TextView editText2 = (TextView) promptView.findViewById(R.id.textView2);
            // setup a dialog window
            alertDialogBuilder.setCancelable(false)
                    .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            dialog.cancel();
                        }
                    });
            // create an alert dialog
            AlertDialog alert = alertDialogBuilder.create();
            alert.setOnShowListener(new DialogInterface.OnShowListener() {

                @Override
                public void onShow(final DialogInterface dialogInterface) {

                    //Button button = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEUTRAL);
                    Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                    // Button button3 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEGATIVE);
                    button2.setTextSize(16);
                    button2.setTextColor(Color.parseColor("#38b259"));

                    button2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            dialogInterface.cancel();
                        }
                    });
                }
            });

            alert.show();
        }
    }

    private void loadSavedPreferences2() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        int first_time = sharedPreferences.getInt("id_v", 0);
        idd = first_time;
        Log.v("TAGDSD", ""+ idd);
    }

    private void savePreferences2(String key, int value) {
        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.commit();

    }
}
