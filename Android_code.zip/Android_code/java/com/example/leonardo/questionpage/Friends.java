package com.example.leonardo.questionpage;

import com.appyvet.materialrangebar.*;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.text.InputType;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.appyvet.materialrangebar.RangeBar;
import com.facebook.login.LoginManager;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static android.app.DialogFragment.STYLE_NO_TITLE;

public class Friends extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    TextView nick, filter, black, meters;
    EditText editNick;
    LinearLayout layOther;
    Switch sw1;
    RadioGroup radius;
    SeekBar seekBar;
    private FirebaseDatabase database;
    int ok_val = 0;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_friends);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Bundle b = getIntent().getExtras();
        if (b != null) {
            //if (b.getInt("ok_val") != 0) {
                int id = b.getInt("ok_val");
                ok_val=id;
                Log.v("TAG_ID", "" + id);

           // }
        }



        nick = (TextView)findViewById(R.id.text2);
        filter = (TextView)findViewById(R.id.text22);
       // black = (TextView)findViewById(R.id.text111);

        meters = (TextView)findViewById(R.id.text112);

        layOther = (LinearLayout)findViewById(R.id.linea111);
        layOther.setVisibility(View.INVISIBLE);

        seekBar = (SeekBar)findViewById(R.id.seek);

        database = FirebaseDatabase.getInstance();



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();


        sw1 = (Switch)findViewById(R.id.switch111);
        loadSavedPreferences();
        loadSavedPreferences1();
        //sw1.setChecked(true);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // TODO Auto-generated method stub
                meters.setText(String.valueOf(progress)+"m");
                savePreferences1("distances_2", progress);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // TODO Auto-generated method stub
            }
        });




        sw1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                savePreferences("CheckBox_Value1", sw1.isChecked());
                if(isChecked){
                   /* for ( int i = 0; i < layOther.getChildCount();  i++ ){
                        View view = layOther.getChildAt(i);
                        view.setEnabled(true);
                        view.setAlpha(1f);// Or whatever you want to do with the view.
                    }*/

                   layOther.setVisibility(View.VISIBLE);
                }
                else {
                   /* for ( int i = 0; i < layOther.getChildCount();  i++ ){
                        View view = layOther.getChildAt(i);
                        view.setEnabled(false);
                        view.setAlpha(0.2f);// Or whatever you want to do with the view.
                    }*/
                    SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref5", MODE_PRIVATE);
                    int name = pref.getInt("id_values", 0);
                    String code = pref.getString("code_values", "");
                    database = FirebaseDatabase.getInstance();
                    String ida = String.valueOf(name);
                    DatabaseReference datRef = database.getReference("group_code");
                    datRef.child(code).child(ida).setValue(null);
                    datRef.child(code).child(ida).setValue(null);


                    layOther.setVisibility(View.INVISIBLE);
                }
            }
        });




        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }
    private void loadSavedPreferences() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        boolean checkBoxValue1 = sharedPreferences.getBoolean("CheckBox_Value1", false);
        if (checkBoxValue1) {
            sw1.setChecked(true);
            layOther.setVisibility(View.VISIBLE);
        } else {
            sw1.setChecked(false);
            layOther.setVisibility(View.INVISIBLE);
        }


    }

    private void savePreferences(String key, boolean value) {

        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager

                .getDefaultSharedPreferences(this);

        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putBoolean(key, value);

        editor.commit();

        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref44", MODE_PRIVATE);
        SharedPreferences.Editor editors = pref.edit();
        editors.putBoolean(key, value);           // Saving boolean - true/false
        editors.commit(); // commit changes

    }

    private void loadSavedPreferences1() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        int distances = sharedPreferences.getInt("distances_2", 1000);
        meters.setText(String.valueOf(distances)+"m");
        seekBar.setProgress(distances);
    }

    private void savePreferences1(String key, int value) {
        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.commit();


        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref45", MODE_PRIVATE);
        SharedPreferences.Editor editors = pref.edit();
        editors.putInt(key, value);           // Saving boolean - true/false
        editors.commit(); // commit changes

    }





   /* protected void showInputDialog1() {

        LayoutInflater layoutInflater = LayoutInflater.from(Friends.this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_nickname, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Friends.this);
        alertDialogBuilder.setView(promptView);
        final EditText userInput = (EditText) promptView.findViewById(R.id.editNick);
        userInput.setAlpha(0.6f);
        userInput.setEnabled(false);
        radius = (RadioGroup) promptView.findViewById(R.id.radioG);
        radius.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int id) {
                int i=2131296304;
                Log.v("message","k:"+radioGroup.getCheckedRadioButtonId());
                if(radioGroup.getCheckedRadioButtonId()==i){
                    userInput.setAlpha(1f);
                    userInput.setEnabled(true);
                }else{
                    userInput.setAlpha(0.6f);
                    userInput.setEnabled(false);
                }
            }
        });





        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create an alert dialog
        final AlertDialog alert = alertDialogBuilder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(final DialogInterface dialogInterface) {

                Button button = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEUTRAL);
                Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                Button button3 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEGATIVE);
                button.setTextSize(18);
                button2.setTextSize(18);
                button3.setTextSize(18);


                button.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {

                    }
                });

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });
            }
        });

        alert.show();
    }*/

  /*  protected void showInputDialog2() {

        LayoutInflater layoutInflater = LayoutInflater.from(Friends.this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_filter, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Friends.this);
        alertDialogBuilder.setView(promptView);


        final TextView filter3 = (TextView)promptView.findViewById(R.id.filter2);
       // final TextView filter4 = (TextView)promptView.findViewById(R.id.filter4);
        filter3.setText("12m - 180m");
       // filter4.setText("180");
        //final TextView filter2 = (TextView)promptView.findViewById(R.id.filter2);
        RangeBar range1 = (RangeBar)promptView.findViewById(R.id.range1);
      //  RangeBar range2 = (RangeBar)promptView.findViewById(R.id.range2);


        range1.setOnRangeBarChangeListener(new RangeBar.OnRangeBarChangeListener() {
            @Override
            public void onRangeChangeListener(RangeBar rangeBar, int leftPinIndex, int rightPinIndex, String leftPinValue, String rightPinValue) {


                    filter3.setText(leftPinValue+"m - "+rightPinValue+"m");





            }

        });



        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                       // showInputDialog1();
                    }
                })


        final AlertDialog alert = alertDialogBuilder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(final DialogInterface dialogInterface) {

                Button button = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEUTRAL);
                Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
              //  Button button3 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEGATIVE);
                button.setTextSize(16);
                button2.setTextSize(16);
             //   button3.setTextSize(16);
               // button2.setBackgroundColor(Color.parseColor("#7fb546"));
                button2.setTextColor(Color.parseColor("#7fb546"));



                button.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {

                    }
                });

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });
            }
        });

        alert.show();
    }*/


   /* protected void showInputDialog3() {
        LayoutInflater layoutInflater = LayoutInflater.from(Friends.this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_blacklist, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Friends.this);
        alertDialogBuilder.setView(promptView);


        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("CONFIRM", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                       // showInputDialog1();
                    }
                })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        final AlertDialog alert = alertDialogBuilder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(final DialogInterface dialogInterface) {

                Button button = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEUTRAL);
                Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                Button button3 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_NEGATIVE);
                button.setTextSize(18);
                button2.setTextSize(18);
                button3.setTextSize(18);


                button.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View view) {

                    }
                });

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                    }
                });
            }
        });

        alert.show();

    }*/





    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.friends, menu);
        return true;
    }

   /* @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            Intent Intent = new Intent(this, GeneralQuestion.class);
            startActivity(Intent);
        }

        return super.onOptionsItemSelected(item);
    }*/

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            if(ok_val==1){
                Intent Intent = new Intent(this, HomePage.class);
                Bundle b2 = new Bundle();
                b2.putInt("ff", 9);
                Intent.putExtras(b2);
                startActivity(Intent);

            }else{
                Intent Intent = new Intent(this, HomePage.class);
                startActivity(Intent);
            }
        }   else if(id == R.id.friend){
            Intent Intent = new Intent(this, Friends.class);
            startActivity(Intent);

        } else if (id == R.id.notification) {
            Intent Intent = new Intent(this, com.example.leonardo.questionpage.Notification.class);
            startActivity(Intent);

        } /*else if (id == R.id.manual) {
            Intent Intent = new Intent(this, Manual.class);
            startActivity(Intent);
        } */else if (id == R.id.questions) {
            Intent Intent = new Intent(this, Last.class);
            startActivity(Intent);
        }else if (id == R.id.contact) {
            Intent Intent = new Intent(this, ContactUs.class);
            startActivity(Intent);
        }else if (id == R.id.exit) {
            LoginManager.getInstance().logOut();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish(); System.exit(1);

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
