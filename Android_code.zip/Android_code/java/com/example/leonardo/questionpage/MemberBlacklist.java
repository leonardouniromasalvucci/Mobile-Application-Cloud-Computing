package com.example.leonardo.questionpage;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class MemberBlacklist extends AppCompatActivity {

    int preSelectedIndex = -1;
    SearchView search;
    ArrayList<UserModel> newList;
    CustomAdapter adapter;
    Button btn1, btn2, btn3;
    List<UserModel> users;
    Spinner sp;
    boolean vcv=false;

    Context c;
    ExpandableListView expandableListView1;
    ExpandableListAdapter expandableListAdapter1;
    List<String> expandableListTitle1;
    HashMap<String, List<String>> expandableListDetail1;



    String[] plants = new String[]{
            "SELECTION OPTIONS",
            "CLEAR",
            "BLOCK ALL",
            "UNBLOCK ALL"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_blacklist);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);



        getSupportActionBar().setTitle("Block profiles");// for set actionbar title
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        c=this;
        final ListView listView = (ListView) findViewById(R.id.listview);
      //  search = (SearchView)findViewById(R.id.search);
      //  search.setQueryHint("Search friend to block...");
      //  search.setIconified(false);
      //  btn1 = (Button)findViewById(R.id.btn);
      //  btn2 = (Button)findViewById(R.id.btn2);
      //  btn3 = (Button)findViewById(R.id.btn3);


        users = new ArrayList<>();
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));

        newList = new ArrayList<UserModel>(users);
        adapter = new CustomAdapter(this, users);
        listView.setAdapter(adapter);

        for(int i=0; i<newList.size();i++){
            UserModel model = newList.get(i);
            model.setSelected(true);
            newList.set(i, model);
        }
        adapter.updateRecords(newList);

       /* sp = (Spinner)findViewById(R.id.spinner11);

        sp.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                return false;
            }
        });*/



      /*  sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String  itemValue    = (String) sp.getItemAtPosition(position);
                Log.v("m", "l:" + id);
                if(position==0){


               }else if(position==1 ){
                   for(int i=0; i<newList.size();i++){
                       UserModel model = newList.get(i);
                       model.setSelected(false);
                       newList.set(i, model);
                   }
                   vcv=false;
                   sp.setSelection(0);
                   adapter.updateRecords(newList);

               }else  if(position==2){
                    for(int i=0; i<newList.size();i++){
                        UserModel model = newList.get(i);
                        model.setSelected(true);
                        newList.set(i, model);
                    }
                    vcv=false;
                    sp.setSelection(0);
                    adapter.updateRecords(newList);

               }else{

               }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {


            }


        });*/






        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this,R.layout.spinner_item,plants){
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                return super.getDropDownView(position + 1, convertView, parent);
            }

            public int getCount() {
                return plants.length - 1;
            }
        };
        spinnerArrayAdapter.setDropDownViewResource(R.layout.spinner_item);
    /*    sp.setAdapter(spinnerArrayAdapter);*/

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                UserModel model = newList.get(i);

                Log.d("message","id");

                if (model.isSelected())
                    model.setSelected(false);

                else
                    model.setSelected(true);

                newList.set(i, model);
                listView.setAdapter(adapter);
                //adapter.updateRecords(users);
            }
        });






      /*  search.setOnQueryTextListener(new SearchView.OnQueryTextListener() {

            @Override
            public boolean onQueryTextChange(String newText) {
                newList.clear();
                for(int i=0; i<users.size(); i++ ){
                    if(users.get(i).userName.toLowerCase().contains(newText.toLowerCase())){
                        newList.add(users.get(i));
                    }
                }
                adapter.updateRecords(newList);
                //listView.setAdapter(adapter);
                return true;
            }

            @Override
            public boolean onQueryTextSubmit(String query) {


                return true;
            }
        });
*/
      /*  btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0; i<newList.size();i++){
                    UserModel model = newList.get(i);
                    model.setSelected(false);
                    newList.set(i, model);
                }
                adapter.updateRecords(newList);
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0; i<newList.size();i++){
                    UserModel model = newList.get(i);
                    model.setSelected(true);
                    newList.set(i, model);
                }
                adapter.updateRecords(newList);
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for(int i=0; i<newList.size();i++){
                    if(newList.get(i).isSelected){
                        Context context = getApplicationContext();
                        CharSequence text = "Select:"+newList.get(i).userName;
                        int duration = Toast.LENGTH_SHORT;

                        Toast toast = Toast.makeText(context, text, duration);
                        toast.show();
                    }

                }
            }
        });*/

        /*expandableListView1 = (ExpandableListView) findViewById(R.id.expand);
        expandableListDetail1 = ExpandableListDataPump1.getData();
        expandableListTitle1 = new ArrayList<String>(expandableListDetail1.keySet());
        Collections.sort(expandableListTitle1);


        expandableListAdapter1 = new CustomExpandableListAdapter1(this, expandableListTitle1, expandableListDetail1);


        expandableListView1.setAdapter(expandableListAdapter1);
        expandableListView1.setTextFilterEnabled(true);


        expandableListView1.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {

            @Override
            public void onGroupExpand(int groupPosition) {
                Toast.makeText(getApplicationContext(),
                        expandableListTitle1.get(groupPosition) + " List Expanded.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        expandableListView1.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {

            @Override
            public void onGroupCollapse(int groupPosition) {
                Toast.makeText(getApplicationContext(),
                        expandableListTitle1.get(groupPosition) + " List Collapsed.",
                        Toast.LENGTH_SHORT).show();

            }
        });

        expandableListView1.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                Toast.makeText(
                        getApplicationContext(),
                        expandableListTitle1.get(groupPosition)
                                + " -> "
                                + expandableListDetail1.get(
                                expandableListTitle1.get(groupPosition)).get(
                                childPosition), Toast.LENGTH_SHORT
                ).show();
                return false;
            }
        });*/
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);

        //SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        android.support.v7.widget.SearchView searchView = (android.support.v7.widget.SearchView) menu.findItem(R.id.menu_search).getActionView();
        // searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setQueryHint("Search profile to block...");
        //searchView.setMaxWidth(220);
        //searchView.setIconified(false);
        searchView.setOnQueryTextListener(new android.support.v7.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                newList.clear();
                for(int i=0; i<users.size(); i++ ){
                    if(users.get(i).userName.toLowerCase().contains(newText.toLowerCase())){
                        newList.add(users.get(i));
                    }
                }
                adapter.updateRecords(newList);
                //listView.setAdapter(adapter);
                return true;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }



  /*  @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Log.v("m", ""+item.getTitle());
        if(item.getTitle().toString().contains("Block all")){
            for(int i=0; i<newList.size();i++){
                UserModel model = newList.get(i);
                model.setSelected(false);
                newList.set(i, model);
            }
            adapter.updateRecords(newList);

        }else if(item.getTitle().toString().contains("Unblock all")){
            for(int i=0; i<newList.size();i++){
                UserModel model = newList.get(i);
                model.setSelected(true);
                newList.set(i, model);
            }
            adapter.updateRecords(newList);

        }else{}


        return super.onOptionsItemSelected(item);

    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {



        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(getApplicationContext(), Blacklist.class);
                startActivity(intent);
                return true;
            case R.id.sel:
                for(int i=0; i<newList.size();i++){
                    UserModel model = newList.get(i);
                    model.setSelected(false);
                    newList.set(i, model);
                }
                adapter.updateRecords(newList);

                return true;
            case R.id.des:
                for(int i=0; i<newList.size();i++){
                    UserModel model = newList.get(i);
                    model.setSelected(true);
                    newList.set(i, model);
                }
                adapter.updateRecords(newList);

                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }




}
