package com.example.leonardo.questionpage;

import android.app.Activity;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;

import com.baoyz.swipemenulistview.SwipeMenu;
import com.baoyz.swipemenulistview.SwipeMenuCreator;
import com.baoyz.swipemenulistview.SwipeMenuItem;
import com.baoyz.swipemenulistview.SwipeMenuListView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

public class Blacklist extends AppCompatActivity {

    ArrayAdapter adapter;
    TextView list_b,chose, unblock, unblock2;
    ListView listView;
    LinkedList<String> list;
    String nome;
    boolean vals = false;
    LinearLayout l;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_blacklist);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
       // setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Blacklist"); // for set actionbar title
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        listView = (ListView) findViewById(R.id.lists);
        list_b = (TextView)findViewById(R.id.chooseBlack);
        l = (LinearLayout)findViewById(R.id.lal);
        l.setVisibility(View.INVISIBLE);
        chose = (TextView)findViewById(R.id.chooseBlack1);
       // chose.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_expand_more_black_24dp, 0);

       // unblock = (TextView)findViewById(R.id.unblock);
      //  unblock.setVisibility(View.INVISIBLE);
       // unblock2 = (TextView)findViewById(R.id.unblock2);
      //  unblock2.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_lock_open_black_24dp, 0, 0, 0);
      //  unblock2.setVisibility(View.INVISIBLE);
        //unblock.setPaintFlags(Paint.UNDERLINE_TEXT_FLAG);

        list = new LinkedList<>();
        list.add("Leonardo Salvucci");
        list.add("Giulio Amici");
        list.add("Martina Ribeca");
        list.add("Dabniele Salvucci");
        list.add("Filippo Gemma");


       /* chose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!vals){
                    chose.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_expand_less_black_24dp, 0);
                    l.setVisibility(View.VISIBLE);
                }else{
                    chose.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_expand_more_black_24dp, 0);
                    l.setVisibility(View.INVISIBLE);
                }
                vals=!vals;
            }
        });
*/


        adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);



        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1, int pos, long id) {
                String  itemValue    = (String) listView.getItemAtPosition(pos);
               // unblock.setVisibility(View.INVISIBLE);
              //  unblock2.setVisibility(View.VISIBLE);
                nome = itemValue;
                Log.v("message","v: "+itemValue);
                return true;
            }
        });

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> arg0, View arg1,  int pos, long id) {
                int itemPosition     = pos;
                String  itemValue    = (String) listView.getItemAtPosition(pos);
                Log.v("message","v: "+itemValue);
               showInputDialog1(pos, itemValue);

                Log.v("long clicked","pos: " + pos);

                return true;
            }
        });



       /* SwipeMenuCreator creator = new SwipeMenuCreator() {

            @Override
            public void create(SwipeMenu menu) {

                // create "delete" item
                SwipeMenuItem deleteItem = new SwipeMenuItem(
                        getApplicationContext());
                // set item background
                deleteItem.setBackground(new ColorDrawable(Color.rgb(0x00, 0x66,
                        0xff)));
                // set item width
                deleteItem.setTitle("UNBLOCK");

                deleteItem.setTitleColor(Color.WHITE);
                deleteItem.setTitleSize(25);
                deleteItem.setWidth(170);
                // set a icon
               // deleteItem.setIcon(R.drawable.ic_all_inclusive_black_24dp);
                // add to menu

                menu.addMenuItem(deleteItem);

            }
        };

        listView.setMenuCreator(creator);*/



        /*listView.setOnMenuItemClickListener(new SwipeMenuListView.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(int position, SwipeMenu menu, int index) {



                switch (index) {
                    case 0:
                        Log.v("message","0: "+position);
                        list.remove(position);
                        listView.setAdapter(adapter);
                        break;

                }

                // false : close the menu; true : not close the menu
                return false;
            }
        });*/


        list_b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 Intent Intent = new Intent(getApplicationContext(), MemberBlacklist.class);
                 startActivity(Intent);
            }
        });

        chose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent Intent = new Intent(getApplicationContext(), BlockedProfile.class);
                startActivity(Intent);
            }
        });
/*
        unblock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInputDialog1();
            }
        });
        unblock2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showInputDialog2();

            }
        });*/



    }

    public void unblock(){

       // unblock2.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_lock_open_black_24dp, 0, 0, 0);
       // unblock2.setVisibility(View.VISIBLE);
       // unblock.setVisibility(View.INVISIBLE);
    }

   protected void showInputDialog1(int num, String nome) {

        // get prompts.xml view
        LayoutInflater layoutInflater = LayoutInflater.from(this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_3, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setView(promptView);
        final int n = num;
        final TextView editText = (TextView) promptView.findViewById(R.id.textView);
        final TextView editText2 = (TextView) promptView.findViewById(R.id.textView2);
        editText.setText("Are you sure to unlock "+ nome.toUpperCase()+"?");

        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("UNBLOCK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        list.remove(n);
                        listView.setAdapter(adapter);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //resultText.setText("Hello, " + editText.getText());
                    }
                });;


        // create an alert dialog
        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
    }

/*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case android.R.id.home:
                Intent intent = new Intent(getApplicationContext(), Friends.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.manual, menu);
        return true;
    }

    /*protected void showInputDialog2() {

        // get prompts.xml view
        LayoutInflater layoutInflater = LayoutInflater.from(this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_3, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setView(promptView);

        final TextView editText = (TextView) promptView.findViewById(R.id.textView);
        final TextView editText2 = (TextView) promptView.findViewById(R.id.textView2);
        // setup a dialog window
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Unblock", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        list.remove(nome);
                        listView.setAdapter(adapter);
                        unblock2.setVisibility(View.INVISIBLE);
                      //  list.clear();
                       // listView.setAdapter(adapter);
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //resultText.setText("Hello, " + editText.getText());
                    }
                });;


        // create an alert dialog
        AlertDialog alert = alertDialogBuilder.create();
        alert.show();
    }*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {



        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(getApplicationContext(), Friends.class);
                startActivity(intent);
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }





}