package com.example.leonardo.questionpage;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.util.Patterns;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphRequestAsyncTask;
import com.facebook.GraphResponse;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.content.pm.Signature;
import android.widget.Toast;


import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FacebookAuthProvider;
import com.google.firebase.auth.FirebaseUser;

import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;

public class LoginActivity extends AppCompatActivity {

    public CallbackManager callbackManager;
    public ProgressDialog mDialog;
    public LoginButton loginButton;
    public Button signIn,Login;
    public EditText username, password;
    public Context c;
    public ProgressBar prog;
    boolean valid;
    private static final String EMAIL = "email";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        setTitle("Where Are My Friends?");
        getcon();
        FacebookSdk.sdkInitialize(getApplicationContext());
        AppEventsLogger.activateApp(this);
        callbackManager = CallbackManager.Factory.create();

        username=(EditText)findViewById(R.id.editText4);
        password=(EditText)findViewById(R.id.editText5);
        prog = (ProgressBar)findViewById(R.id.progressBar);


        loginButton = (LoginButton) findViewById(R.id.login_button);
        loginButton.setReadPermissions(Arrays.asList("public_profile","user_birthday"));

        Login = (Button) findViewById(R.id.button2);
        signIn = (Button) findViewById(R.id.button5);

        c=this;

        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), SigniIn.class);
                startActivity(intent);
            }
        });

        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {

            @Override
            public void onSuccess(final LoginResult loginResult) {
                Log.v("FACEBOOK LOGIN", "CORRECT");

                AccessToken accessToken = loginResult.getAccessToken();
                GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                        display_data(object,loginResult.getAccessToken().getToken());
                    }
                });
                Bundle bundle = new Bundle();
                bundle.putString("fields", "id,name,email,birthday");
                request.setParameters(bundle);
                request.executeAsync();
            }

            @Override
            public void onCancel() {
                Log.v("FACEBOKKKKKKK", "");

            }

            @Override
            public void onError(FacebookException error) {
                Log.v("FACEBOOK ERROR: ", error.toString());

            }
        });

        Login.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                valid=true;
                if(!isEmpty(username)){
                    username.setError("Insert a username");
                    valid=false;
                }
                if(!isEmpty(password)){
                    password.setError("Insert a password");
                    valid=false;
                }

                if(valid) {
                    prog.setVisibility(View.VISIBLE);

                    RequestQueue queue = Volley.newRequestQueue(c);
                    String url = "https://ancient-cove-76988.herokuapp.com/login?username=" + username.getText().toString() + "&password=" + md5(password.getText().toString());
                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    if (response.length() == 0) {
                                        prog.setVisibility(View.INVISIBLE);
                                        showInputDialog1();


                                    } else {
                                        Intent Intent = new Intent(getApplicationContext(), ChooseCode.class);
                                        Bundle b = new Bundle();
                                        b.putInt("key", Integer.parseInt(response));
                                        Bundle b1 = new Bundle();
                                        b1.putInt("log", 9);
                                        Bundle b2 = new Bundle();
                                        b2.putString("name", username.getText().toString());
                                        Intent.putExtras(b); //Put your id to your next Intent
                                        Intent.putExtras(b1);
                                        Intent.putExtras(b2);
                                        startActivity(Intent);
                                        finish();
                                    }
                                    Log.v("TAG", "Response is: " + response);
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Log.v("TAG", "That didn't work!");
                        }
                    });
                    queue.add(stringRequest);
                }
            }
        });

    }

    private void display_data(JSONObject object, String key){
        Log.v("MESS", object.toString());
        String id="",name="",email="",birthday="";
        try {
            id = object.getString("id");
            name = object.getString("name");
            email = object.getString("email");
            birthday = object.getString("birthday");

            Log.v("ID", id);
            Log.v("NAME", name);
            Log.v("EMAIL", email);
            Log.v("BIRTHDAY", birthday);
            Log.v("TOKEN", key);

        } catch (JSONException e) {
            e.printStackTrace();
        }

        long n = Long.parseLong(id);
        Integer nn = (int)(long)n;

        Intent Intent = new Intent(getApplicationContext(), ChooseCode.class);
        Bundle b = new Bundle();
        b.putInt("key", Math.abs(nn));
        Intent.putExtras(b); //Put your id to your next Intent
        Bundle b2 = new Bundle();
        b2.putString("name", name);
        Intent.putExtras(b2);
        startActivity(Intent);
        finish();

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
    }
    public static final String md5(final String s) {
        final String MD5 = "MD5";
        try {
            MessageDigest digest = java.security.MessageDigest
                    .getInstance(MD5);
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();
            StringBuilder hexString = new StringBuilder();
            for (byte aMessageDigest : messageDigest) {
                String h = Integer.toHexString(0xFF & aMessageDigest);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    protected void showInputDialog1() {
        LayoutInflater layoutInflater = LayoutInflater.from(LoginActivity.this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_4, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(LoginActivity.this);
        alertDialogBuilder.setView(promptView);
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Try again", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });
        AlertDialog alert = alertDialogBuilder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(final DialogInterface dialogInterface) {
                Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                button2.setTextSize(16);
                button2.setTextColor(Color.parseColor("#38b259"));

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialogInterface.cancel();
                    }
                });
            }
        });
        alert.show();
    }

    boolean isEmpty(EditText text){
        CharSequence str = text.getText().toString();
        return (!TextUtils.isEmpty(str));
    }

    protected void showInputDialog3() {
        LayoutInflater layoutInflater = LayoutInflater.from(LoginActivity.this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_not_internet, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(LoginActivity.this);
        alertDialogBuilder.setView(promptView);
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Try again", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        getcon();
                    }
                });
        AlertDialog alert = alertDialogBuilder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(final DialogInterface dialogInterface) {
                Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                button2.setTextSize(16);
                button2.setTextColor(Color.parseColor("#38b259"));

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        NetworkInfo netInfo = cm.getActiveNetworkInfo();
                        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
                            showInputDialog3();
                        }else{
                            dialogInterface.cancel();
                        }
                    }
                });
            }
        });
        alert.show();
    }



    public void getcon(){
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
            showInputDialog3();
        }else{
            Log.v("MESSAGE","Connection ok");
        }

    }



}
