package com.example.leonardo.questionpage;

import android.app.ActionBar;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SigniIn extends AppCompatActivity {

    public EditText username,email,password,date;
    public Button signIn;
    public Context c;
    boolean valid = true;
    public ProgressBar prog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signi_in);
        setTitle("Sign in");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        username = (EditText)findViewById(R.id.usernames);
        email = (EditText)findViewById(R.id.emails);
        password = (EditText)findViewById(R.id.passwords);
        date = (EditText)findViewById(R.id.dates);
        signIn = (Button)findViewById(R.id.button2);
        prog = (ProgressBar)findViewById(R.id.progressBar1);
        c=this;


        signIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                valid=true;
                // Instantiate the RequestQueue.
                if(!isEmpty(username)){
                    username.setError("Insert a username");
                    valid=false;
                }
                if(!isEmail(email)){
                    email.setError("Insert a valid email");
                    valid=false;
                }
                if(!isEmpty(password)){
                    password.setError("Insert a password");
                    valid=false;
                }
                if(!isEmpty(date)){
                    date.setError("Insert a date");
                    valid=false;
                }
                if(valid) {
                    prog.setVisibility(View.VISIBLE);
                    String p = md5(password.getText().toString());
                    RequestQueue queue = Volley.newRequestQueue(c);
                    String url = "https://ancient-cove-76988.herokuapp.com/test_db?username=" + username.getText() + "&email=" + email.getText() + "&password=" + p + "&date=" + date.getText() + "";

                    StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                            new Response.Listener<String>() {
                                @Override
                                public void onResponse(String response) {
                                    prog.setVisibility(View.INVISIBLE);

                                    AlertDialog alertDialog = new AlertDialog.Builder(SigniIn.this).create();
                                    alertDialog.setTitle("Registration was successful");
                                    alertDialog.setMessage("Your registration was successful. Now you can log in.");
                                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "GO BACK",
                                            new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int which) {
                                                    Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                                                    startActivity(intent);
                                                }
                                            });
                                    alertDialog.show();

                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            prog.setVisibility(View.INVISIBLE);
                            AlertDialog alertDialog = new AlertDialog.Builder(SigniIn.this).create();
                            alertDialog.setTitle("Error during registration");

                            //alertDialog.setMessage();
                            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "GO BACK",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {
                                            dialog.dismiss();
                                        }
                                    });
                            alertDialog.show();
                            Log.v("TAG", "That didn't work!");
                        }
                    });
                    queue.add(stringRequest);
                }
            }
        });

    }

    public void onClickBtn(View v){
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(intent);

    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    public static final String md5(final String s) {
        final String MD5 = "MD5";
        try {
            // Create MD5 Hash
            MessageDigest digest = java.security.MessageDigest
                    .getInstance(MD5);
            digest.update(s.getBytes());
            byte messageDigest[] = digest.digest();

            // Create Hex String
            StringBuilder hexString = new StringBuilder();
            for (byte aMessageDigest : messageDigest) {
                String h = Integer.toHexString(0xFF & aMessageDigest);
                while (h.length() < 2)
                    h = "0" + h;
                hexString.append(h);
            }
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }

    boolean isEmail(EditText text){
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());

    }

    boolean isEmpty(EditText text){
        CharSequence str = text.getText().toString();
        return (!TextUtils.isEmpty(str));
    }
}
