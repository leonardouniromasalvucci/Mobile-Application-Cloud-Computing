package com.example.leonardo.questionpage;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Application;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.FacebookSdk;
import com.facebook.internal.WebDialog;
import com.facebook.login.LoginManager;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

import bolts.Task;

import static com.facebook.FacebookSdk.getApplicationContext;

public class HomePage extends AppCompatActivity implements OnMapReadyCallback, NavigationView.OnNavigationItemSelectedListener {



    LinearLayout lin;
    private GoogleMap mMap;
    private FirebaseDatabase database;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;
    int first = 0;
    int id_user=0;
    double my_f_la=0.0, my_f_lo=0.0;
    int doub_id=0;
    String code_g;
    List<String> l;
    private final AtomicLong counter = new AtomicLong();
    int act_call=0;
    LocationManager lm;
    TextView tt;
    String s="",name_user="";
    TextView txt1,txt2;
    int vvv=0;
    int verify=0;
    boolean name=false;

    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("Map");
        getcona();
        //txt1=(TextView)findViewById(R.id.yourid);
        txt2=(TextView)findViewById(R.id.groupcode);


            FacebookSdk.sdkInitialize(this);
            lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

            l = new ArrayList<String>();
            counter.addAndGet(-1);

            Bundle b = getIntent().getExtras();
            if (b != null) {
                if (b.getInt("key") != 0) {
                    int id = b.getInt("key");
                    Log.v("TAG_ID", "" + id);
                    savePreferences2("id_user", id);

                }
            }
            Bundle b1 = getIntent().getExtras();
            if (b1 != null) {
                if (b1.getString("key_code") != null) {
                    String code = b1.getString("key_code");
                    Log.v("TAG_GR", "" + code);
                    savePreferences3("group_code", code);
                }
            }
            Bundle b2 = getIntent().getExtras();
            if (b2 != null) {
                act_call = b2.getInt("ff");
                Log.v("TAG", "" + act_call);
            }
             Bundle b3 = getIntent().getExtras();
             if (b3 != null) {
                if (b3.getString("name") != null) {
                   String name = b3.getString("name");
                   Log.v("TAG_GR", "" + name);
                   savePreferences4("name", name);
                }
             }

            loadSavedPreferences2();
            loadSavedPreferences3();
            loadSavedPreferences4();




        SharedPreferences prefs = getApplicationContext().getSharedPreferences("MyPref5", MODE_PRIVATE);
        SharedPreferences.Editor editorss = prefs.edit();
        editorss.putInt("id_values", id_user);
        editorss.putString("code_values", code_g);  // Saving boolean - true/false
        editorss.commit(); // commit changes

       // txt1.setText("Your id: "+id_user);
        txt2.setText("Group code: "+code_g);


        loadSavedPreferences1();

        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref44", MODE_PRIVATE);
        boolean name = pref.getBoolean("CheckBox_Value1", false);


        if(name) {
            sendDataToFirebase1(id_user, code_g,name_user);

            // Obtain the SupportMapFragment and get notified when the map is ready to be used.
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);

            lin = (LinearLayout) findViewById(R.id.layx);
            database = FirebaseDatabase.getInstance();

            DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
            ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                    this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
            drawer.addDrawerListener(toggle);
            toggle.syncState();

            NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(this);
            if (first == 0) {
                DatabaseInitializer.populateAsync(AppDatabase.getAppDatabase(this));
            }
            savePreferences1("first", 1);

            SharedPreferences pref2 = getApplicationContext().getSharedPreferences("MyPref45", MODE_PRIVATE);
            vvv = pref2.getInt("distances_2", 1000);
            Log.v("DISTANCEEEEE", "BBBBBBBBBBBBBBBBBBBBBBBBBBB:::::"+vvv);


        }else{
            AlertDialog alertDialog = new AlertDialog.Builder(HomePage.this).create();
            alertDialog.setTitle("MAP ERROR");
            alertDialog.setMessage("\n" +
                    "The page can not be loaded. Unlock the visibility.");
            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, "UNBLOCK",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            if(act_call==9){
                                Intent intent = new Intent(getApplicationContext(), Friends.class);
                                Bundle b = new Bundle();
                                b.putInt("ok_val", 1);
                                intent.putExtras(b); //Put your id to your next Intent
                                startActivity(intent);

                            }else{
                                Intent intent = new Intent(getApplicationContext(), Friends.class);
                                Bundle b = new Bundle();
                                b.putInt("ok_val", 0);
                                intent.putExtras(b); //Put your id to your next Intent
                                startActivity(intent);
                            }

                        }
                    });
            alertDialog.show();

        }
    }


    private void loadSavedPreferences1() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        int first_time = sharedPreferences.getInt("first", 0);
        first = first_time;
    }

    private void savePreferences1(String key, int value) {
        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.commit();

    }




    private void loadSavedPreferences2() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        int first_time = sharedPreferences.getInt("id_user", 0);
        id_user = first_time;
        Log.v("USERRRRRRR",""+id_user);
    }

    private void savePreferences2(String key, int value) {
        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.commit();

    }



    private void loadSavedPreferences3() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String first_time = sharedPreferences.getString("group_code", "");
        code_g = first_time;
        Log.v("CODEEEEEEE",""+code_g);
    }

    private void savePreferences3(String key, String value) {
        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();

    }

    private void loadSavedPreferences4() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        String first_time = sharedPreferences.getString("name", "");
        name_user = first_time;
        Log.v("NAMEEEEE",""+name_user);
    }

    private void savePreferences4(String key, String value) {
        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;
        enableMyLocationIfPermitted();
        mMap.moveCamera(CameraUpdateFactory.zoomBy(9));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(my_f_la, my_f_lo), 9));
        mMap.clear();

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        lm.requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER, 0, 0, new LocationListener() {
                    @Override
                    public void onStatusChanged(String provider, int status, Bundle extras) {
                    }
                    @Override
                    public void onProviderEnabled(String provider) {
                    }
                    @Override
                    public void onProviderDisabled(String provider) {
                    }
                    @Override
                    public void onLocationChanged(final Location location) {
                        my_f_la = location.getLatitude();
                        my_f_lo = location.getLongitude();
                        String idd = String.valueOf(id_user);
                        sendDataToFirebase(idd,my_f_la,my_f_lo,name_user);
                        Log.v("POSITION", "location changed by:"+idd+"-lat:"+my_f_la+"-long:"+my_f_lo+"-name:"+name_user);
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(my_f_la, my_f_lo), 9));
                    }
                });
    }

    private void enableMyLocationIfPermitted() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else if (mMap != null) {
            mMap.setMyLocationEnabled(true);
            String v = String.valueOf(id_user);
            final Location myLocation = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            my_f_la = myLocation.getLatitude();
            my_f_lo = myLocation.getLongitude();
            sendDataToFirebase(v,myLocation.getLatitude(),myLocation.getLongitude(),name_user);
            mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(myLocation.getLatitude(), myLocation.getLongitude())));
            SharedPreferences pref2 = getApplicationContext().getSharedPreferences("MyPref45", MODE_PRIVATE);
            vvv = pref2.getInt("distances_2", 1000);
            Log.v("DISTANCEEEEE", "BBBBBBBBBBBBBBBBBBBBBBBBBBB:::::"+vvv);
            verify=1;
            showMap();
            //mMap.moveCamera(CameraUpdateFactory.zoomBy(16));



        }
    }
    private void sendDataToFirebase(String id, double lat, double lon,String names) {
        database = FirebaseDatabase.getInstance();
        DatabaseReference datRef = database.getReference("wacc-f9b60");
        datRef.child(id).child("latitude").setValue(lat);
        datRef.child(id).child("longitude").setValue(lon);
        datRef.child(id).child("name").setValue(names);
    }
    private void sendDataToFirebase1(int id, String code, String names) {
        database = FirebaseDatabase.getInstance();
        DatabaseReference datRef = database.getReference("group_code");
        String ids = String.valueOf(id);
        datRef.child(code).child(ids).setValue("");
        getataToFirebase1(code);
    }

    private void getataToFirebase1(String code) {
        database = FirebaseDatabase.getInstance();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("group_code").child(code);
        ref.addListenerForSingleValueEvent(
                new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        l.clear();
                        String idsa=String.valueOf(id_user);
                        for(DataSnapshot data : dataSnapshot.getChildren()) {
                            Log.i("id_user of group", data.getKey());
                            if (data.getKey()!=idsa) {
                                l.add(data.getKey());
                            }
                        }
                        l.remove(idsa);


                        if(act_call==9){
                            startThreadListening();
                        }
                        showMap();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        //handle databaseError
                    }
                });
    }

    public void showMap(){
        DatabaseReference datRef = database.getReference("wacc-f9b60");
        datRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                mMap.clear();
                for(DataSnapshot data : dataSnapshot.getChildren()) {

                   if(l.contains(data.getKey())){

                           double la = Double.parseDouble(data.child("latitude").getValue().toString());
                           double lo = Double.parseDouble(data.child("longitude").getValue().toString());
                           String n = data.child("name").getValue().toString();
                           Log.v("LATITUDEEEEE", "AAAAAAAAAAAAAAAAAAAAAAAAAAA:::::"+la);
                           Log.v("LONGITUDEEEE", "AAAAAAAAAAAAAAAAAAAAAAAAAAA:::::"+lo);
                           Log.v("NAMEEEEEEEEE", "AAAAAAAAAAAAAAAAAAAAAAAAAAA:::::"+n);

                           float[] results = new float[1];
                           Location.distanceBetween(my_f_la, my_f_lo, la, lo, results);
                           DecimalFormat twoDForm = new DecimalFormat("#,##");
                           Log.v("DISTANCEEEEE", "AAAAAAAAAAAAAAAAAAAAAAAAAAA:::::"+vvv);
                           if(results[0]<=vvv) {
                               if (results[0] > 30000) {
                                   mMap.addMarker(new MarkerOptions().position(new LatLng(la, lo)).snippet("Away in elaboration...").title(n).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
                                   mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(la, lo)));
                               } else {
                                   if (results[0] > 1000) {
                                       double nn = results[0] / 1000;
                                       mMap.addMarker(new MarkerOptions().position(new LatLng(la, lo)).snippet("Away " + Double.valueOf(twoDForm.format(nn)) + " km").title(n).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
                                       mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(la, lo)));

                                   } else {
                                       mMap.addMarker(new MarkerOptions().position(new LatLng(la, lo)).snippet("Away " + Double.valueOf(twoDForm.format(results[0])) + " m").title(n).icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
                                       mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(la, lo)));

                                   }
                               }
                           }else{
                               mMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(la, lo)));
                           }
                   }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void startThreadListening(){
        for (int i = 0; i < l.size(); i++) {
            new Thread(new Runnable() {
                public void run() {
                    Thread thread = Thread.currentThread();
                    long n = counter.incrementAndGet();
                    int nn = (int) n;
                    System.out.println("I'm running "+thread.getId()+" and I'm listening for user: " + l.get(nn));
                    //list.add(thread);
                    DatabaseReference datRef = database.getReference("wacc-f9b60").child(l.get(nn));
                    datRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot1) {
                            int k=0;
                            if(l.contains(dataSnapshot1.getKey())){
                                Log.i("TEST", "" + dataSnapshot1.getKey());
                                double la = Double.parseDouble(dataSnapshot1.child("latitude").getValue().toString());
                                double lo = Double.parseDouble(dataSnapshot1.child("longitude").getValue().toString());
                                String names = dataSnapshot1.child("name").getValue().toString();
                                SharedPreferences pref22 = getApplicationContext().getSharedPreferences("MyPref", MODE_PRIVATE);
                                boolean allow = pref22.getBoolean("allow", false);
                                boolean vib = pref22.getBoolean("vibration", false);
                                boolean sound = pref22.getBoolean("sound", false);

                                SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref3", MODE_PRIVATE);
                                int name = pref.getInt("nearby", 0);

                                SharedPreferences pref2 = getApplicationContext().getSharedPreferences("MyPref2", MODE_PRIVATE);
                                int name2 = pref2.getInt("distances", 0);
                                float[] results1 = new float[1];
                                Location.distanceBetween(my_f_la, my_f_lo, la, lo, results1);
                                showMap();

                                if(results1[0]<=name2){
                                    if(name==1) {
                                        if(allow){
                                            if(k==0){
                                                NotificationHelper2 n = new NotificationHelper2(getApplicationContext());
                                                n.createNotification("Friend near", names+" is near you");
                                                k++;

                                            }

                                        }
                                    }
                                }




                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            System.out.println("The read failed: " + databaseError.getCode());
                        }
                    });

                }
            }).start();
        }
    }


    private void showDefaultLocation() {
        Toast.makeText(this, "Location permission not granted, " +
                        "showing default location",
                Toast.LENGTH_SHORT).show();
        LatLng redmond = new LatLng(41.8919300, 12.5113300);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(redmond));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {
            case LOCATION_PERMISSION_REQUEST_CODE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    enableMyLocationIfPermitted();
                } else {
                    showDefaultLocation();
                }
                return;
            }

        }
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_page, menu);
        return true;
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_camera) {
            Intent Intent = new Intent(this, HomePage.class);
            startActivity(Intent);
        }   else if (id == R.id.notification) {
            Intent Intent = new Intent(this, Notification.class);
            startActivity(Intent);

        }else if (id == R.id.friend) {
            Intent Intent = new Intent(this, Friends.class);
            startActivity(Intent);


        }  else if (id == R.id.questions) {
            Intent Intent = new Intent(this, Last.class);
            startActivity(Intent);
        }else if (id == R.id.contact) {
            Intent Intent = new Intent(this, ContactUs.class);
            startActivity(Intent);
        }else if (id == R.id.exit) {
            LoginManager.getInstance().logOut();
            Intent intent = new Intent(this, LoginActivity.class);
            startActivity(intent);
            finish();
            System.exit(1);


        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    protected void showInputDialog3() {
        LayoutInflater layoutInflater = LayoutInflater.from(HomePage.this);
        View promptView = layoutInflater.inflate(R.layout.input_dialogue_not_internet, null);
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(HomePage.this);
        alertDialogBuilder.setView(promptView);
        alertDialogBuilder.setCancelable(false)
                .setPositiveButton("Try again", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        getcona();
                    }
                });
        AlertDialog alert = alertDialogBuilder.create();
        alert.setOnShowListener(new DialogInterface.OnShowListener() {

            @Override
            public void onShow(final DialogInterface dialogInterface) {
                Button button2 = ((AlertDialog) dialogInterface).getButton(AlertDialog.BUTTON_POSITIVE);
                button2.setTextSize(16);
                button2.setTextColor(Color.parseColor("#38b259"));

                button2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
                        NetworkInfo netInfo = cm.getActiveNetworkInfo();
                        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
                            showInputDialog3();
                        }else{
                            dialogInterface.cancel();
                        }
                    }
                });
            }
        });
        alert.show();
    }
    public void getcona(){
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo == null || !netInfo.isConnectedOrConnecting()) {
            showInputDialog3();
        }else{
            Log.v("MESSAGE","Connection ok");
        }

    }





}
