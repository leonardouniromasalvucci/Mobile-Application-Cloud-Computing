package com.example.leonardo.questionpage;

public class Manu {

    public String categoria;
    public int ids;

    public Manu(String categoria, int ids, String descrizione) {
        this.categoria = categoria;
        this.ids = ids;
        this.descrizione = descrizione;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public int getIds() {
        return ids;
    }

    public void setIds(int ids) {
        this.ids = ids;
    }

    public String getDescrizione() {
        return descrizione;
    }

    public void setDescrizione(String descrizione) {
        this.descrizione = descrizione;
    }

    public String descrizione;





}
