package com.example.leonardo.questionpage;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class CustomizeNotification extends AppCompatActivity {

    ArrayList<UserModel> newList;
    CustomAdapter3 adapter;
    List<UserModel> users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_customize_notification);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        getSupportActionBar().setTitle("Customize notifications"); // for set actionbar title
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        final ListView listView = (ListView) findViewById(R.id.listview5);
        users = new ArrayList<>();
        users.add(new UserModel(true, "Nearby friends"));
       // users.add(new UserModel(true, "Free classroom nearby"));
        users.add(new UserModel(true, "System"));

        newList = new ArrayList<UserModel>(users);
        adapter = new CustomAdapter3(this, users);
        listView.setAdapter(adapter);
        loadSavedPreferences1();
        /*for(int i=0; i<newList.size();i++){
            UserModel model = newList.get(i);
            model.setSelected(true);
            newList.set(i, model);
        }*/
        adapter.updateRecords(newList);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                UserModel model = newList.get(i);

                Log.d("message","id");

                if (model.isSelected()) {
                    model.setSelected(false);
                    if(model.getUserName()=="System") {
                        savePreferences1("system", 0);
                    }else{
                        savePreferences1("nearby", 0);
                    }
                }else {
                    model.setSelected(true);
                    if(model.getUserName()=="System") {
                        savePreferences1("system", 1);
                    }else{
                        savePreferences1("nearby", 1);
                    }
                }

                newList.set(i, model);
                listView.setAdapter(adapter);
                //adapter.updateRecords(users);
            }
        });




    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {



        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(getApplicationContext(), Notification.class);
                startActivity(intent);
                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void loadSavedPreferences1() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        int nearby = sharedPreferences.getInt("nearby", 0);
        int system = sharedPreferences.getInt("system", 0);
        for(int i=0; i<newList.size();i++){
            UserModel model = newList.get(i);
            if(model.getUserName()=="System"){
                if(system==0){
                    model.setSelected(false);
                }else{
                    model.setSelected(true);
                }
            }else{
                if(nearby==0){
                    model.setSelected(false);
                }else{
                    model.setSelected(true);
                }
            }
            newList.set(i, model);
        }


    }

    private void savePreferences1(String key, int value) {
        SharedPreferences sharedPreferences;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.commit();

        SharedPreferences pref = getApplicationContext().getSharedPreferences("MyPref3", MODE_PRIVATE);
        SharedPreferences.Editor editors = pref.edit();
        editors.putInt(key, value);           // Saving boolean - true/false
        editors.commit(); // commit changes
    }


}
