package com.example.leonardo.questionpage;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

public class BlockedProfile extends AppCompatActivity {


    SearchView search;
    ArrayList<UserModel> newList;
    CustomAdapter1 adapter;
    List<UserModel> users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blocked_profile);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setTitle("Blocked profiles");// for set actionbar title
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        final ListView listView = (ListView) findViewById(R.id.listview2);
        users = new ArrayList<>();
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));
        users.add(new UserModel(false, "Leonardo Salvucci"));
        users.add(new UserModel(false, "Giulio Laureti"));
        users.add(new UserModel(false, "Daniele Salvucci"));
        users.add(new UserModel(false, "Federico Angeli"));

        newList = new ArrayList<UserModel>(users);
        adapter = new CustomAdapter1(this, users);
        listView.setAdapter(adapter);

        for(int i=0; i<newList.size();i++){
            UserModel model = newList.get(i);
            model.setSelected(false);
            newList.set(i, model);
        }
        adapter.updateRecords(newList);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                UserModel model = newList.get(i);

                Log.d("message","id");

                if (model.isSelected())
                    model.setSelected(false);

                else
                    model.setSelected(true);

                newList.set(i, model);
                listView.setAdapter(adapter);
                //adapter.updateRecords(users);
            }
        });
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_search, menu);

        //SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        android.support.v7.widget.SearchView searchView = (android.support.v7.widget.SearchView) menu.findItem(R.id.menu_search).getActionView();
        // searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setQueryHint("Search profile to block...");
        //searchView.setMaxWidth(220);
        //searchView.setIconified(false);
        searchView.setOnQueryTextListener(new android.support.v7.widget.SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                newList.clear();
                for(int i=0; i<users.size(); i++ ){
                    if(users.get(i).userName.toLowerCase().contains(newText.toLowerCase())){
                        newList.add(users.get(i));
                    }
                }
                adapter.updateRecords(newList);
                //listView.setAdapter(adapter);
                return true;
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {



        switch (item.getItemId()) {
            case android.R.id.home:
                Intent intent = new Intent(getApplicationContext(), Blacklist.class);
                startActivity(intent);
                return true;
            case R.id.sel:
                for(int i=0; i<newList.size();i++){
                    UserModel model = newList.get(i);
                    model.setSelected(false);
                    newList.set(i, model);
                }
                adapter.updateRecords(newList);

                return true;
            case R.id.des:
                for(int i=0; i<newList.size();i++){
                    UserModel model = newList.get(i);
                    model.setSelected(true);
                    newList.set(i, model);
                }
                adapter.updateRecords(newList);

                return true;


            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
